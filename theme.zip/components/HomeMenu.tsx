
import React from 'react';
import XIcon from './icons/XIcon';
import ArchiveIcon from './icons/ArchiveIcon';
import StarIcon from './icons/StarIcon';
import LockIcon from './icons/LockIcon';
import PdfIcon from './icons/PdfIcon';
import TrashIcon from './icons/TrashIcon';
import HomeIcon from './icons/HomeIcon';
import SettingsIcon from './icons/SettingsIcon';
import BackupIcon from './icons/BackupIcon';
import KeyIcon from './icons/KeyIcon';
import InsightsIcon from './icons/InsightsIcon';

interface HomeMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
  isPasswordSet: boolean;
  onSetPassword: () => void;
}

const HomeMenu: React.FC<HomeMenuProps> = ({ isOpen, onClose, onNavigate, currentPage, isPasswordSet, onSetPassword }) => {
  
  const handleUnsupportedClick = (page: string) => {
     console.log(`${page} clicked, but page is not implemented.`);
  }

  const defaultMenuItems = [
    { icon: <HomeIcon className="h-6 w-6" />, label: 'Home', action: () => onNavigate('home') },
    { icon: <ArchiveIcon className="h-6 w-6" />, label: 'Archive', action: () => onNavigate('archive') },
    { icon: <StarIcon className="h-6 w-6" />, label: 'Favorites', action: () => onNavigate('favorites') },
    { icon: <LockIcon className="h-6 w-6" />, label: "Locked Notes", action: () => onNavigate('locked') },
    { icon: <PdfIcon className="h-6 w-6" />, label: 'PDFs', action: () => onNavigate('pdfs') },
    { icon: <InsightsIcon className="h-6 w-6" />, label: 'Insights', action: () => onNavigate('insights') },
    { icon: <SettingsIcon className="h-6 w-6" />, label: 'Settings', action: () => onNavigate('settings') },
    { icon: <TrashIcon className="h-6 w-6" />, label: 'Trash', action: () => onNavigate('trash') },
    { icon: <BackupIcon className="h-6 w-6" />, label: 'Back up', action: () => handleUnsupportedClick('Backup') },
  ];

  const lockedMenuItems = [
    { icon: <HomeIcon className="h-6 w-6" />, label: 'Home', action: () => onNavigate('home') },
    { icon: <ArchiveIcon className="h-6 w-6" />, label: 'Archive', action: () => onNavigate('archive') },
    { icon: <StarIcon className="h-6 w-6" />, label: 'Favorites', action: () => onNavigate('favorites') },
    { icon: <KeyIcon className="h-6 w-6" />, label: isPasswordSet ? 'Change Password' : 'Set Password', action: onSetPassword },
    { icon: <TrashIcon className="h-6 w-6" />, label: 'Trash', action: () => onNavigate('trash') },
  ];

  const menuItems = currentPage === 'locked' ? lockedMenuItems : defaultMenuItems;

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-50 bg-black/60 transition-opacity duration-300 ease-in-out ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
        aria-hidden="true"
      ></div>

      {/* Menu Panel */}
      <div
        className={`fixed top-0 left-0 h-full w-full max-w-xs bg-gray-100 dark:bg-gray-900 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="menu-title"
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
            <h2 id="menu-title" className="text-lg font-semibold text-gray-900 dark:text-white">
              Menu
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 dark:focus:ring-offset-gray-900 focus:ring-gray-500"
              aria-label="Close menu"
            >
              <XIcon className="h-6 w-6" />
            </button>
          </div>

          {/* Menu Items */}
          <nav className="flex-grow p-2">
            <ul className="space-y-1">
              {menuItems.map(({ icon, label, action }) => (
                <li key={label}>
                  <button
                    type="button"
                    className="w-full flex items-center space-x-4 px-4 py-3 text-left text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white rounded-lg transition-colors duration-200"
                    onClick={() => { action(); onClose(); }}
                  >
                    {icon}
                    <span className="font-medium">{label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </>
  );
};

export default HomeMenu;