
import React from 'react';

interface Action {
  name: string;
  icon: React.ReactNode;
  handler: () => void;
  show: boolean;
}

interface MultiSelectBottomBarProps {
  actions: Action[];
}

const MultiSelectBottomBar: React.FC<MultiSelectBottomBarProps> = ({
  actions,
}) => {
  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-lg z-40 border-t border-gray-900 animate-fadeIn">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-around h-16">
          {actions.filter(action => action.show).map((action) => (
            <button
              key={action.name}
              type="button"
              onClick={action.handler}
              className="flex flex-col items-center p-2 rounded-lg text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-colors w-20"
              aria-label={action.name}
            >
              {action.icon}
              <span className="text-xs mt-1">{action.name}</span>
            </button>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default MultiSelectBottomBar;
