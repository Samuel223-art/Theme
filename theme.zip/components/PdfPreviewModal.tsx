import React, { useState, useRef, useLayoutEffect, useEffect, useCallback, useMemo } from 'react';
import { Note } from '../App';
import ChevronDownIcon from './icons/ChevronDownIcon';

declare const jspdf: any;
declare const html2canvas: any;

interface PdfPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (noteId: string, title: string, pdfDataUrl: string) => void;
  note: Note;
}

type PagePreset = 'A4' | 'Letter' | 'Legal' | 'Custom';
type PageUnit = 'px' | 'in';
type FontSize = 10 | 12 | 14 | 16;

const DPI = 96; // Standard DPI for px conversion

const PRESET_DIMENSIONS_IN: Record<Exclude<PagePreset, 'Custom'>, { width: number; height: number }> = {
  A4: { width: 8.27, height: 11.69 },
  Letter: { width: 8.5, height: 11 },
  Legal: { width: 8.5, height: 14 },
};

const PADDING_MM = 15;

const inchToMm = (inches: number) => inches * 25.4;
const pxToMm = (px: number) => (px * 25.4) / DPI;
const mmToPx = (mm: number) => (mm * DPI) / 25.4;


const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({ isOpen, onClose, onSave, note }) => {
  const [pagePreset, setPagePreset] = useState<PagePreset>('A4');
  const [pageUnit, setPageUnit] = useState<PageUnit>('in');
  const [pageWidth, setPageWidth] = useState<string>('8.27');
  const [pageHeight, setPageHeight] = useState<string>('11.69');
  
  const [fontSize, setFontSize] = useState<FontSize>(12);
  const [isSaving, setIsSaving] = useState(false);
  const [isGenerating, setIsGenerating] = useState(true);
  const [totalPages, setTotalPages] = useState(0);
  const [pageContentHeightPx, setPageContentHeightPx] = useState(0);
  const [scale, setScale] = useState(1);
  
  const [isPresetDropdownOpen, setIsPresetDropdownOpen] = useState(false);
  const [isFontSizeDropdownOpen, setIsFontSizeDropdownOpen] = useState(false);

  const previewContainerRef = useRef<HTMLDivElement>(null);
  const presetDropdownRef = useRef<HTMLDivElement>(null);
  const fontSizeDropdownRef = useRef<HTMLDivElement>(null);
  
  const pageDimsMm = useMemo(() => {
    if (pagePreset !== 'Custom') {
        const dimsIn = PRESET_DIMENSIONS_IN[pagePreset];
        return {
            width: inchToMm(dimsIn.width),
            height: inchToMm(dimsIn.height)
        };
    }

    const widthNum = parseFloat(pageWidth) || 0;
    const heightNum = parseFloat(pageHeight) || 0;

    if (pageUnit === 'in') {
        return {
            width: inchToMm(widthNum),
            height: inchToMm(heightNum)
        };
    } else { // 'px'
        return {
            width: pxToMm(widthNum),
            height: pxToMm(heightNum)
        };
    }
  }, [pagePreset, pageWidth, pageHeight, pageUnit]);


  useLayoutEffect(() => {
    const updateScale = () => {
      if (!previewContainerRef.current || !isOpen) return;
      const containerWidth = previewContainerRef.current.clientWidth;
      const previewWidth = mmToPx(pageDimsMm.width);
      
      const effectiveContainerWidth = containerWidth - 40; 
      
      if (previewWidth > effectiveContainerWidth) {
        setScale(effectiveContainerWidth / previewWidth);
      } else {
        setScale(1);
      }
    };

    if (isOpen) {
        const timer = setTimeout(updateScale, 50);
        window.addEventListener('resize', updateScale);
        return () => {
            clearTimeout(timer);
            window.removeEventListener('resize', updateScale);
        };
    }
  }, [isOpen, pageDimsMm.width]);
  
  const closeDropdowns = useCallback((event: MouseEvent) => {
    if (presetDropdownRef.current && !presetDropdownRef.current.contains(event.target as Node)) {
        setIsPresetDropdownOpen(false);
    }
    if (fontSizeDropdownRef.current && !fontSizeDropdownRef.current.contains(event.target as Node)) {
        setIsFontSizeDropdownOpen(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.addEventListener('mousedown', closeDropdowns);
    }
    return () => {
        document.removeEventListener('mousedown', closeDropdowns);
    };
  }, [isOpen, closeDropdowns]);


  useEffect(() => {
    if (!isOpen) return;

    setIsGenerating(true);
    const timer = setTimeout(() => {
        const pageContentHeightMm = pageDimsMm.height - PADDING_MM * 2;
        const pageContentHeight = mmToPx(pageContentHeightMm);
        setPageContentHeightPx(pageContentHeight);

        const measurer = document.createElement('div');
        measurer.style.position = 'absolute';
        measurer.style.left = '-9999px';
        measurer.style.width = `${mmToPx(pageDimsMm.width - PADDING_MM * 2)}px`;
        measurer.style.visibility = 'hidden';
        
        const measurerContent = document.createElement('div');
        measurerContent.className = 'prose-preview';
        measurerContent.style.fontSize = `${fontSize}pt`;
        measurerContent.innerHTML = note.content;
        measurer.appendChild(measurerContent);
        
        document.body.appendChild(measurer);
        
        const totalHeight = measurer.scrollHeight;
        const numPages = totalHeight > 0 ? Math.ceil(totalHeight / pageContentHeight) : 1;
        
        setTotalPages(numPages);
        document.body.removeChild(measurer);
        setIsGenerating(false);

    }, 100);

    return () => clearTimeout(timer);

  }, [isOpen, note.content, fontSize, pageDimsMm]);

  const handleSave = async () => {
    if (isSaving || totalPages === 0) return;
    setIsSaving(true);
    try {
        const { jsPDF } = jspdf;
        const pdf = new jsPDF({
            orientation: pageDimsMm.width > pageDimsMm.height ? 'landscape' : 'portrait',
            unit: 'mm',
            format: [pageDimsMm.width, pageDimsMm.height]
        });

        const captureTarget = document.createElement('div');
        captureTarget.style.position = 'absolute';
        captureTarget.style.left = '-9999px';
        captureTarget.style.background = 'white';
        captureTarget.style.width = `${pageDimsMm.width}mm`;
        
        const captureContent = document.createElement('div');
        captureContent.className = 'prose-preview';
        captureContent.style.padding = `${PADDING_MM}mm`;
        captureContent.style.fontSize = `${fontSize}pt`;
        captureContent.innerHTML = note.content;
        
        captureTarget.appendChild(captureContent);
        document.body.appendChild(captureTarget);
        
        const fullCanvas = await html2canvas(captureTarget, {
            scale: 2,
            useCORS: true,
        });

        document.body.removeChild(captureTarget);

        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const canvasSliceHeight = (pdfHeight / pdfWidth) * fullCanvas.width;

        for (let i = 0; i < totalPages; i++) {
            if (i > 0) pdf.addPage();
            
            const sliceCanvas = document.createElement('canvas');
            sliceCanvas.width = fullCanvas.width;
            sliceCanvas.height = canvasSliceHeight;
            const ctx = sliceCanvas.getContext('2d');
            
            if (ctx) {
                ctx.drawImage(
                    fullCanvas,
                    0, i * canvasSliceHeight, // source y
                    fullCanvas.width, canvasSliceHeight, // source width, height
                    0, 0, // dest x, y
                    fullCanvas.width, canvasSliceHeight // dest width, height
                );
                
                const imgData = sliceCanvas.toDataURL('image/png');
                pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            }
        }
        
        const pdfDataUrl = pdf.output('datauristring');
        onSave(note.id, note.title, pdfDataUrl);

    } catch (error) {
        console.error('Failed to generate PDF', error);
        alert('Could not generate PDF. Please try again.');
    } finally {
        setIsSaving(false);
    }
  };
  
  const fontSizes: FontSize[] = [10, 12, 14, 16];
  const pagePresets: PagePreset[] = ['A4', 'Letter', 'Legal', 'Custom'];
  
  const handlePresetSelect = (preset: PagePreset) => {
    setPagePreset(preset);
    setIsPresetDropdownOpen(false);
    if (preset !== 'Custom') {
        const dimsIn = PRESET_DIMENSIONS_IN[preset];
        if (pageUnit === 'in') {
            setPageWidth(dimsIn.width.toString());
            setPageHeight(dimsIn.height.toString());
        } else { // px
            setPageWidth(Math.round(dimsIn.width * DPI).toString());
            setPageHeight(Math.round(dimsIn.height * DPI).toString());
        }
    }
  };

  const handleUnitChange = (newUnit: PageUnit) => {
    if (pageUnit === newUnit) return;

    const widthNum = parseFloat(pageWidth) || 0;
    const heightNum = parseFloat(pageHeight) || 0;

    if (newUnit === 'px') { // from 'in' to 'px'
        setPageWidth(Math.round(widthNum * DPI).toString());
        setPageHeight(Math.round(heightNum * DPI).toString());
    } else { // from 'px' to 'in'
        setPageWidth((widthNum / DPI).toFixed(2));
        setPageHeight((heightNum / DPI).toFixed(2));
    }
    setPageUnit(newUnit);
  };

  const handleFontSizeSelect = (size: FontSize) => {
    setFontSize(size);
    setIsFontSizeDropdownOpen(false);
  };
  
  function SegmentedControl<T extends string>({ options, value, onChange }: { options: { value: T; label?: string; }[]; value: T; onChange: (value: T) => void; }) {
    return (
        <div className="flex items-center bg-gray-800 p-0.5 rounded-md">
            {options.map(option => (
                <button
                    key={option.value}
                    type="button"
                    onClick={() => onChange(option.value)}
                    className={`px-2 py-1 text-xs font-semibold rounded-sm transition-colors ${value === option.value ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700/50'}`}
                >
                    {option.label}
                </button>
            ))}
        </div>
    );
  }

  return (
    <div
      className={`fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm transition-opacity duration-300 ease-in-out ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      aria-labelledby="pdf-modal-title" role="dialog" aria-modal={isOpen} onClick={onClose}
    >
      <div
        className={`bg-gray-900 rounded-lg shadow-xl w-full h-full max-w-4xl max-h-[90vh] m-4 flex flex-col transform transition-all duration-300 ease-in-out ${isOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 sm:p-6 border-b border-gray-800 flex items-center justify-between flex-wrap gap-4">
          <h2 id="pdf-modal-title" className="text-xl font-bold text-white truncate pr-4 flex-shrink min-w-0">
            PDF Preview: {note.title}
          </h2>
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            {/* Font size dropdown */}
            <div ref={fontSizeDropdownRef} className="relative">
                <button type="button" onClick={() => setIsFontSizeDropdownOpen(!isFontSizeDropdownOpen)} className="flex items-center justify-between w-28 px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-gray-500" aria-haspopup="listbox" aria-expanded={isFontSizeDropdownOpen}>
                    <span>{fontSize} pt</span>
                    <ChevronDownIcon className={`h-5 w-5 text-gray-400 transition-transform duration-200 ${isFontSizeDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isFontSizeDropdownOpen && (
                    <ul className="absolute right-0 mt-2 w-28 bg-gray-800 border border-gray-700 rounded-md shadow-lg z-10 animate-fadeIn" role="listbox">
                        {fontSizes.map((size) => (
                            <li key={size}>
                                <button type="button" onClick={() => handleFontSizeSelect(size)} className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-700" role="option" aria-selected={size === fontSize}>
                                    {size} pt
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
             {/* Page preset dropdown */}
            <div ref={presetDropdownRef} className="relative">
                <button type="button" onClick={() => setIsPresetDropdownOpen(!isPresetDropdownOpen)} className="flex items-center justify-between w-32 px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-gray-500" aria-haspopup="listbox" aria-expanded={isPresetDropdownOpen}>
                    <span>{pagePreset}</span>
                    <ChevronDownIcon className={`h-5 w-5 text-gray-400 transition-transform duration-200 ${isPresetDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isPresetDropdownOpen && (
                    <ul className="absolute right-0 mt-2 w-32 bg-gray-800 border border-gray-700 rounded-md shadow-lg z-10 animate-fadeIn" role="listbox">
                        {pagePresets.map((preset) => (
                            <li key={preset}>
                                <button type="button" onClick={() => handlePresetSelect(preset)} className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-700" role="option" aria-selected={preset === pagePreset}>
                                    {preset}
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
          </div>
        </div>

        {pagePreset === 'Custom' && (
            <div className="p-3 bg-gray-800/50 border-b border-gray-800 flex items-center justify-center gap-2 animate-fadeIn">
                 <input type="number" value={pageWidth} onChange={(e) => setPageWidth(e.target.value)} className="w-24 px-2 py-1 bg-gray-900 border border-gray-700 rounded-md text-white text-center focus:outline-none focus:ring-2 focus:ring-gray-500" aria-label="Page width"/>
                 <span className="text-gray-400 text-sm">x</span>
                 <input type="number" value={pageHeight} onChange={(e) => setPageHeight(e.target.value)} className="w-24 px-2 py-1 bg-gray-900 border border-gray-700 rounded-md text-white text-center focus:outline-none focus:ring-2 focus:ring-gray-500" aria-label="Page height"/>
                 <SegmentedControl value={pageUnit} onChange={handleUnitChange} options={[{value: 'in', label: 'in'}, {value: 'px', label: 'px'}]} />
            </div>
        )}
        
        <div ref={previewContainerRef} className="flex-grow bg-gray-800/50 p-4 sm:p-8 overflow-auto flex justify-center items-start">
            {isGenerating ? (
                <div className="text-gray-400">Generating preview...</div>
            ) : (
                <div style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }} className="transition-transform duration-200 space-y-4">
                    {Array.from({ length: totalPages }).map((_, i) => (
                        <div key={i} className="bg-white shadow-lg text-black overflow-hidden" style={{ width: `${pageDimsMm.width}mm`, height: `${pageDimsMm.height}mm` }}>
                           <div className="prose-preview" style={{ padding: `${PADDING_MM}mm`, height: `${pageContentHeightPx * totalPages}px`, transform: `translateY(-${i * pageContentHeightPx}px)`, fontSize: `${fontSize}pt` }}>
                                <div dangerouslySetInnerHTML={{ __html: note.content }} />
                           </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
        <div className="bg-gray-800/50 px-6 py-4 flex justify-between items-center rounded-b-lg border-t border-gray-800">
          <span className="text-sm text-gray-400">Pages: {totalPages}</span>
          <div className="flex space-x-3">
              <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-700 text-white text-sm font-medium rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-colors">
                Cancel
              </button>
              <button type="button" onClick={handleSave} disabled={isSaving || isGenerating} className="px-4 py-2 bg-gray-200 text-gray-900 text-sm font-medium rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-400 transition-colors disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed">
                {isSaving ? 'Saving...' : 'Save PDF'}
              </button>
          </div>
        </div>
        <style>{`
          .prose-preview, .prose-measurer { line-height: 1.5; color: #000; font-family: sans-serif; }
          .prose-preview h1, .prose-measurer h1 { color: #000; font-size: 2em; margin-bottom: 1em; font-weight: bold; }
          .prose-preview h2, .prose-measurer h2 { color: #000; font-size: 1.5em; margin-bottom: 0.8em; font-weight: bold; }
          .prose-preview p, .prose-measurer p { margin-bottom: 1em; }
          .prose-preview a, .prose-measurer a { color: #000; text-decoration: underline; }
          .prose-preview strong, .prose-measurer strong { color: #000; font-weight: bold; }
          .prose-preview ul, .prose-preview ol, .prose-measurer ul, .prose-measurer ol { color: #000; padding-left: 1.5em; margin-bottom: 1em; }
          .prose-preview ul, .prose-measurer ul { list-style-type: disc; }
          .prose-preview ol, .prose-measurer ol { list-style-type: decimal; }
          .prose-preview * { color: #000 !important; }
          /* Hide number input spinners */
          input[type=number]::-webkit-inner-spin-button, 
          input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none; 
            margin: 0; 
          }
          input[type=number] {
            -moz-appearance: textfield;
          }
        `}</style>
      </div>
    </div>
  );
};

export default PdfPreviewModal;
