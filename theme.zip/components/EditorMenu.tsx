
import React from 'react';
import XIcon from './icons/XIcon';
import ArchiveIcon from './icons/ArchiveIcon';
import SearchIcon from './icons/SearchIcon';
import StarIcon from './icons/StarIcon';
import LockIcon from './icons/LockIcon';
import PdfIcon from './icons/PdfIcon';
import TrashIcon from './icons/TrashIcon';
import HistoryIcon from './icons/HistoryIcon';
import { Note } from '../App';
import RenameIcon from './icons/RenameIcon';
import PinIcon from './icons/PinIcon';

interface EditorMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onTrash: () => void;
  onDeletePermanently: () => void;
  onToggleArchive: () => void;
  onToggleFavorite: () => void;
  onToggleLock: () => void;
  onTogglePin: () => void;
  onShowVersions: () => void;
  onFind: () => void;
  onConvertToPdf: () => void;
  onRename: () => void;
  isArchived?: boolean;
  isFavorite?: boolean;
  isLocked?: boolean;
  isPinned?: boolean;
  note: Note;
}

const EditorMenu: React.FC<EditorMenuProps> = ({
  isOpen,
  onClose,
  onTrash,
  onDeletePermanently,
  onToggleArchive,
  onToggleFavorite,
  onToggleLock,
  onTogglePin,
  onShowVersions,
  onFind,
  onConvertToPdf,
  onRename,
  isArchived,
  isFavorite,
  isLocked,
  isPinned,
  note,
}) => {
  const hasVersions = note.versions && note.versions.length > 0;

  const deleteAction = {
    name: 'delete',
    icon: <TrashIcon className="h-6 w-6" />,
    label: isLocked ? 'Delete Permanently' : 'Move to Trash',
    action: isLocked ? onDeletePermanently : onTrash,
  };

  const menuItems = [
    !isLocked && !isArchived && { name: 'pin', icon: <PinIcon className="h-6 w-6" />, label: isPinned ? 'Unpin note' : 'Pin note', action: onTogglePin },
    !isLocked && { name: 'archive', icon: <ArchiveIcon className="h-6 w-6" />, label: isArchived ? 'Unarchive' : 'Archive', action: onToggleArchive },
    { name: 'find', icon: <SearchIcon className="h-6 w-6" />, label: 'Find', action: onFind },
    { name: 'rename', icon: <RenameIcon className="h-6 w-6" />, label: 'Rename', action: onRename },
    !isLocked && !isArchived && { name: 'favorite', icon: <StarIcon className="h-6 w-6" />, label: isFavorite ? 'Remove from favourites' : 'Add to favourites', action: onToggleFavorite },
    { name: 'lock', icon: <LockIcon className="h-6 w-6" />, label: isLocked ? 'Unlock' : 'Lock', action: onToggleLock },
    { name: 'versions', icon: <HistoryIcon className="h-6 w-6" />, label: 'Versions', action: onShowVersions, disabled: !hasVersions },
    { name: 'pdf', icon: <PdfIcon className="h-6 w-6" />, label: 'Convert to PDF', action: onConvertToPdf },
    deleteAction,
  ].filter(Boolean) as { name: string; icon: JSX.Element; label: string; action: () => void; disabled?: boolean }[];

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-30 bg-black/60 transition-opacity duration-300 ease-in-out ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
        aria-hidden="true"
      ></div>

      {/* Menu Panel */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-xs bg-gray-900 shadow-2xl z-40 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="menu-title"
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-800">
            <h2 id="menu-title" className="text-lg font-semibold text-white">
              Editor's Menu
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500"
              aria-label="Close menu"
            >
              <XIcon className="h-6 w-6" />
            </button>
          </div>

          {/* Menu Items */}
          <nav className="flex-grow p-2">
            <ul className="space-y-1">
              {menuItems.map(({ name, icon, label, action, disabled }) => (
                <li key={name}>
                  <button
                    type="button"
                    disabled={disabled}
                    className={`w-full flex items-center space-x-4 px-4 py-3 text-left rounded-lg transition-colors duration-200 ${
                      name === 'delete' 
                      ? 'text-red-500 hover:bg-red-500/10'
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                    } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                    onClick={() => {
                      action();
                      onClose();
                    }}
                  >
                    {icon}
                    <span className="font-medium">{label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </>
  );
};

export default EditorMenu;
