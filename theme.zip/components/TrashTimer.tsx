
import React, { useState, useEffect } from 'react';

const TRASH_DURATION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds

const lerp = (a: number, b: number, p: number) => a * (1 - p) + b * p;

const getColor = (percentage: number) => {
  const p = percentage / 100;
  let r, g, b;

  // Green: rgb(74, 222, 128)
  const green = { r: 74, g: 222, b: 128 };
  // Yellow: rgb(250, 204, 21)
  const yellow = { r: 250, g: 204, b: 21 };
  // Orange: rgb(251, 146, 60)
  const orange = { r: 251, g: 146, b: 60 };
  // Red: rgb(239, 68, 68)
  const red = { r: 239, g: 68, b: 68 };

  if (p < 0.33) {
    const localP = p / 0.33;
    r = lerp(green.r, yellow.r, localP);
    g = lerp(green.g, yellow.g, localP);
    b = lerp(green.b, yellow.b, localP);
  } else if (p < 0.66) {
    const localP = (p - 0.33) / 0.33;
    r = lerp(yellow.r, orange.r, localP);
    g = lerp(yellow.g, orange.g, localP);
    b = lerp(yellow.b, orange.b, localP);
  } else {
    const localP = (p - 0.66) / 0.34;
    r = lerp(orange.r, red.r, localP);
    g = lerp(orange.g, red.g, localP);
    b = lerp(orange.b, red.b, localP);
  }

  return `rgb(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)})`;
};

const formatTimeLeft = (ms: number) => {
  if (ms <= 0) return 'Deleting soon...';
  
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / (3600 * 24));
  const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);

  if (days > 0) return `${days}d ${hours}h left`;
  if (hours > 0) return `${hours}h ${minutes}m left`;
  if (minutes > 0) return `${minutes}m left`;
  return `Less than a minute left`;
};

interface TrashTimerProps {
  trashedAt: string;
}

const TrashTimer: React.FC<TrashTimerProps> = ({ trashedAt }) => {
  const calculateState = () => {
    const trashedDate = new Date(trashedAt).getTime();
    const now = new Date().getTime();
    const elapsed = now - trashedDate;
    const timeLeft = TRASH_DURATION_MS - elapsed;
    const percentage = Math.min(100, (elapsed / TRASH_DURATION_MS) * 100);
    return { timeLeft, percentage };
  };
  
  const [timerState, setTimerState] = useState(calculateState);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setTimerState(calculateState());
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [trashedAt]);

  const barColor = getColor(timerState.percentage);

  return (
    <div className="absolute bottom-0 left-0 right-0 h-5 bg-gray-700/50">
      <div 
        className="h-full transition-all"
        style={{ width: `${timerState.percentage}%`, backgroundColor: barColor, transitionDuration: '60s', transitionTimingFunction: 'linear' }}
      ></div>
      <div className="absolute inset-0 flex items-center justify-center">
         <span className="text-xs text-white font-semibold" style={{ textShadow: '0 0 3px rgba(0,0,0,0.7)' }}>
            {formatTimeLeft(timerState.timeLeft)}
         </span>
      </div>
    </div>
  );
};

export default TrashTimer;
