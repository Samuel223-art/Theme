
import React, { useState, useEffect, useRef } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import SearchIcon from './icons/SearchIcon';
import { Note } from '../App';
import NoteGrid from './NoteGrid';

interface SearchPageProps {
  notes: Note[];
  onBack: () => void;
  onNoteSelect: (note: Note) => void;
  layout: 'grid' | 'list';
  density: 'comfortable' | 'compact';
}

const SearchPage: React.FC<SearchPageProps> = ({ notes, onBack, onNoteSelect, layout, density }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Note[]>([]);

  useEffect(() => {
    // Autofocus the input when the component mounts
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (query.trim() === '') {
      setResults([]);
      return;
    }

    const lowerCaseQuery = query.toLowerCase();

    const stripHtml = (html: string): string => {
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = html;
      return tempDiv.textContent || tempDiv.innerText || '';
    };

    const searchedNotes = notes
      .map(note => {
        const titleText = note.title.toLowerCase();
        const contentText = stripHtml(note.content).toLowerCase();

        const titleMatch = titleText.includes(lowerCaseQuery);
        const contentMatch = contentText.includes(lowerCaseQuery);
        
        let score = 0;
        if (titleMatch) {
          score += 10; // Title match is more important
        }
        if (contentMatch) {
           // Score based on number of occurrences
           try {
             score += (contentText.match(new RegExp(lowerCaseQuery, 'g')) || []).length;
           } catch (e) {
             // Handle invalid regex from user input
             if (contentText.includes(lowerCaseQuery)) score += 1;
           }
        }

        return { ...note, score };
      })
      .filter(note => note.score > 0)
      .sort((a, b) => b.score - a.score);

    setResults(searchedNotes);
  }, [query, notes]);

  const handleNotePress = (note: Note) => {
    onNoteSelect(note);
  };

  return (
    <div className="fixed inset-0 bg-black z-50 animate-fadeIn flex flex-col">
      <header className="bg-black/80 backdrop-blur-lg sticky top-0 z-10 border-b border-gray-900 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 space-x-4">
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
              aria-label="Go back"
            >
              <ArrowLeftIcon className="h-6 w-6" />
            </button>
            <div className="flex-grow relative">
              <input
                ref={inputRef}
                type="search"
                placeholder="Search notes..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-900 border border-transparent rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="h-5 w-5 text-gray-500" />
              </div>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-grow p-4 sm:p-6 lg:p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          {query.trim() === '' ? (
            <div className="text-center py-10">
              <p className="text-gray-500">Start typing to search for your notes.</p>
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-gray-500">No notes found for "{query}".</p>
            </div>
          ) : (
            <NoteGrid
              notes={results}
              handleNotePress={handleNotePress}
              handleNoteLongPress={() => {}} // No long press action in search results
              selectedNoteIds={new Set()} // No selections in search results
              layout={layout}
              density={density}
            />
          )}
        </div>
      </main>
    </div>
  );
};

export default SearchPage;
