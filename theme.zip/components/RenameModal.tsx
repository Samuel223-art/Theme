
import React, { useState, useEffect, useRef } from 'react';
import { Note } from '../App';

interface RenameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmRename: (noteId: string, newTitle: string) => void;
  note: Note;
}

const RenameModal: React.FC<RenameModalProps> = ({ isOpen, onClose, onConfirmRename, note }) => {
  const [newTitle, setNewTitle] = useState(note.title);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setNewTitle(note.title);
      // Focus input after a short delay to allow for modal transition
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen, note.title]);

  const handleConfirm = () => {
    const trimmedTitle = newTitle.trim();
    if (trimmedTitle) {
      onConfirmRename(note.id, trimmedTitle);
    }
  };

  const isInvalid = !newTitle.trim();

  return (
    <div
      className={`fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm transition-opacity duration-300 ease-in-out ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      aria-labelledby="rename-modal-title"
      role="dialog"
      aria-modal={isOpen}
      onClick={onClose}
    >
      <div
        className={`bg-gray-900 rounded-lg shadow-xl w-full max-w-md m-4 transform transition-all duration-300 ease-in-out ${isOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          <h2 id="rename-modal-title" className="text-xl font-bold text-white mb-4">
            Rename Note
          </h2>
          <div>
            <label htmlFor="note-title-rename" className="sr-only">
              New note title
            </label>
            <input
              ref={inputRef}
              type="text"
              id="note-title-rename"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !isInvalid && handleConfirm()}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-gray-500"
              placeholder="Enter new title..."
            />
          </div>
        </div>
        <div className="bg-gray-800/50 px-6 py-4 flex justify-end space-x-3 rounded-b-lg">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gray-700 text-white text-sm font-medium rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={isInvalid}
            className="px-4 py-2 bg-gray-200 text-gray-900 text-sm font-medium rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-400 transition-colors disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default RenameModal;
