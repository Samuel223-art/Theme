
import React from 'react';
import { PdfFile } from '../App';
import PdfCard from './PdfCard';

interface PdfPageProps {
  pdfs: PdfFile[];
}

const PdfPage: React.FC<PdfPageProps> = ({ pdfs }) => {
  return (
    <>
      {pdfs.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {pdfs.map(pdf => (
            <PdfCard 
              key={pdf.id} 
              pdf={pdf}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-gray-500">No PDFs saved yet.</p>
          <p className="text-gray-600 text-sm mt-2">You can convert a note to a PDF from the editor's menu.</p>
        </div>
      )}
    </>
  );
};

export default PdfPage;
