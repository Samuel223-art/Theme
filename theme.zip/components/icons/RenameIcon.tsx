
import React from 'react';
import { IconProps } from './IconProps';

const RenameIcon: React.FC<IconProps> = ({ className }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 19V5" />
      <path d="M5 19h14" />
      <path d="M5 5h14" />
    </svg>
  );
};

export default RenameIcon;
