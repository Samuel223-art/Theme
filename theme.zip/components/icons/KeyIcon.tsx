
import React from 'react';
import { IconProps } from './IconProps';

const KeyIcon: React.FC<IconProps> = ({ className }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4v-1a1 1 0 011-1h2-2-2a1 1 0 01-1-1v-2h2v-2h2v-2h2l1.5-1.5m3.5-3.5a2 2 0 00-2-2h-3.586a1 1 0 00-.707.293L6.414 11.414a1 1 0 00.293.707V14a2 2 0 002 2h4.586a1 1 0 00.707-.293l4.293-4.293a2 2 0 000-2.828z" />
    </svg>
  );
};

export default KeyIcon;
