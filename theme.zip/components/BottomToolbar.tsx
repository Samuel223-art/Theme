import React from 'react';
import BoldIcon from './icons/BoldIcon';
import UndoIcon from './icons/UndoIcon';
import RedoIcon from './icons/RedoIcon';
import ListBulletIcon from './icons/ListBulletIcon';
import ListNumberedIcon from './icons/ListNumberedIcon';
import AlignLeftIcon from './icons/AlignLeftIcon';
import AlignCenterIcon from './icons/AlignCenterIcon';
import AlignRightIcon from './icons/AlignRightIcon';
import Heading1Icon from './icons/Heading1Icon';
import Heading2Icon from './icons/Heading2Icon';
import UnderlineIcon from './icons/UnderlineIcon';
import StrikethroughIcon from './icons/StrikethroughIcon';
import HighlightIcon from './icons/HighlightIcon';
import CodeIcon from './icons/CodeIcon';
import BlockquoteIcon from './icons/BlockquoteIcon';
import IndentIcon from './icons/IndentIcon';
import OutdentIcon from './icons/OutdentIcon';
import HorizontalRuleIcon from './icons/HorizontalRuleIcon';


interface BottomToolbarProps {
  bottomInset: number;
}

const BottomToolbar: React.FC<BottomToolbarProps> = ({ bottomInset }) => {
  const handleFormat = (command: string, value?: string) => {
    document.execCommand(command, false, value);
  };
  
  const handleHighlight = () => {
    // Using backColor as hiliteColor is deprecated. This is the most compatible way.
    // We check if the current selection is already highlighted and remove it if so.
    const highlightColor = 'rgb(254, 240, 138)'; // Equivalent to Tailwind's yellow-200
    const isHighlighted = document.queryCommandValue('backColor') === highlightColor;
    
    if (isHighlighted) {
      document.execCommand('backColor', false, 'transparent');
    } else {
      document.execCommand('backColor', false, highlightColor);
    }
  };

  const handleCodeBlock = () => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
        handleFormat('insertHTML', '<pre><code>&nbsp;</code></pre>');
        return;
    };
    const range = selection.getRangeAt(0);
    const selectedText = range.toString();

    // Sanitize the text to be placed inside a PRE.
    const sanitizedText = document.createTextNode(selectedText).textContent || '';

    const html = `<pre><code>${sanitizedText || '&nbsp;'}</code></pre>`;
    handleFormat('insertHTML', html);
  };
  
  const ToolButton: React.FC<{ onClick?: () => void; ariaLabel: string; children: React.ReactNode }> = ({ onClick, ariaLabel, children }) => (
    <button
      type="button"
      onMouseDown={(e) => e.preventDefault()} // Prevent editor from losing focus
      onClick={onClick}
      className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200 flex-shrink-0"
      aria-label={ariaLabel}
    >
      {children}
    </button>
  );

  return (
    <footer 
      style={{ paddingBottom: `${bottomInset}px` }}
      className="w-full bg-black/80 backdrop-blur-lg z-20 border-t border-gray-900 transition-[padding-bottom] duration-200 ease-in-out"
    >
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-start h-14 space-x-1 sm:space-x-2 overflow-x-auto whitespace-nowrap">
          <ToolButton ariaLabel="Undo" onClick={() => handleFormat('undo')}>
            <UndoIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Redo" onClick={() => handleFormat('redo')}>
            <RedoIcon className="h-6 w-6" />
          </ToolButton>
          
          <div className="h-6 w-px bg-gray-700 mx-2 flex-shrink-0"></div>

          <ToolButton ariaLabel="Bold" onClick={() => handleFormat('bold')}>
            <BoldIcon className="h-6 w-6" />
          </ToolButton>
           <ToolButton ariaLabel="Underline" onClick={() => handleFormat('underline')}>
            <UnderlineIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Strikethrough" onClick={() => handleFormat('strikeThrough')}>
            <StrikethroughIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Highlight" onClick={handleHighlight}>
            <HighlightIcon className="h-6 w-6" />
          </ToolButton>
          

          <div className="h-6 w-px bg-gray-700 mx-2 flex-shrink-0"></div>

          <ToolButton ariaLabel="Heading 1" onClick={() => handleFormat('formatBlock', 'H1')}>
            <Heading1Icon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Subheading" onClick={() => handleFormat('formatBlock', 'H2')}>
            <Heading2Icon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Blockquote" onClick={() => handleFormat('formatBlock', 'blockquote')}>
            <BlockquoteIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Code block" onClick={handleCodeBlock}>
            <CodeIcon className="h-6 w-6" />
          </ToolButton>

          <div className="h-6 w-px bg-gray-700 mx-2 flex-shrink-0"></div>
          
          <ToolButton ariaLabel="Bulleted list" onClick={() => handleFormat('insertUnorderedList')}>
            <ListBulletIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Numbered list" onClick={() => handleFormat('insertOrderedList')}>
            <ListNumberedIcon className="h-6 w-6" />
          </ToolButton>

          <div className="h-6 w-px bg-gray-700 mx-2 flex-shrink-0"></div>
          
           <ToolButton ariaLabel="Outdent" onClick={() => handleFormat('outdent')}>
            <OutdentIcon className="h-6 w-6" />
          </ToolButton>
           <ToolButton ariaLabel="Indent" onClick={() => handleFormat('indent')}>
            <IndentIcon className="h-6 w-6" />
          </ToolButton>
          
          <div className="h-6 w-px bg-gray-700 mx-2 flex-shrink-0"></div>

          <ToolButton ariaLabel="Align left" onClick={() => handleFormat('justifyLeft')}>
            <AlignLeftIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Align center" onClick={() => handleFormat('justifyCenter')}>
            <AlignCenterIcon className="h-6 w-6" />
          </ToolButton>
          <ToolButton ariaLabel="Align right" onClick={() => handleFormat('justifyRight')}>
            <AlignRightIcon className="h-6 w-6" />
          </ToolButton>

           <div className="h-6 w-px bg-gray-700 mx-2 flex-shrink-0"></div>

           <ToolButton ariaLabel="Insert horizontal rule" onClick={() => handleFormat('insertHorizontalRule')}>
            <HorizontalRuleIcon className="h-6 w-6" />
          </ToolButton>

          <div className="w-2 flex-shrink-0"></div>
        </div>
      </div>
      <style>{`
        .overflow-x-auto::-webkit-scrollbar {
            display: none;
        }
        .overflow-x-auto {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </footer>
  );
};

export default BottomToolbar;