
import React, { useState, useMemo, useEffect } from 'react';
import { Note } from '../App';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import TrashTimer from './TrashTimer';

// Helper function to strip HTML and count words/chars
const analyzeText = (html: string) => {
    if (!html) return { words: 0, characters: 0 };
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    const text = tempDiv.textContent || tempDiv.innerText || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    return {
        words: words,
        characters: text.length,
    };
};

const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

const StatCard: React.FC<{ title: string; value: string | number }> = ({ title, value }) => (
    <div className="bg-gray-900 p-4 rounded-lg border border-gray-800 text-center sm:text-left">
      <p className="text-sm text-gray-400">{title}</p>
      <p className="text-2xl font-bold text-white mt-1">{value}</p>
    </div>
);

const InsightsPage: React.FC<{ notes: Note[]; onBack: () => void; }> = ({ notes, onBack }) => {
    const [storageInfo, setStorageInfo] = useState<{ used: number; quota: number; percentage: number; } | null>(null);

    const generalStats = useMemo(() => {
        let totalWords = 0;
        let totalCharacters = 0;
        const activeNotes = notes.filter(n => !n.isTrashed);

        activeNotes.forEach(note => {
            const analysis = analyzeText(note.content);
            totalWords += analysis.words;
            totalCharacters += analysis.characters;
        });

        return {
            totalNotes: activeNotes.length,
            totalWords,
            totalCharacters,
            totalTokens: Math.round(totalCharacters / 4),
        };
    }, [notes]);

    const categoryStats = useMemo(() => {
        return {
            archived: notes.filter(n => n.isArchived && !n.isTrashed).length,
            favorites: notes.filter(n => n.isFavorite && !n.isTrashed).length,
            locked: notes.filter(n => n.isLocked && !n.isTrashed).length,
            trash: notes.filter(n => n.isTrashed).length,
        };
    }, [notes]);

    const trashedNotes = useMemo(() => {
        return notes.filter(n => n.isTrashed)
            .sort((a, b) => new Date(a.trashedAt!).getTime() - new Date(b.trashedAt!).getTime());
    }, [notes]);

    const chartData = useMemo(() => {
        const now = new Date();
        const data: { [key: string]: number } = {};
        const labels: string[] = [];
        const timeRange = 7; // Fixed to 7 days

        for (let i = 0; i < timeRange; i++) {
            const date = new Date(now);
            date.setDate(now.getDate() - i);
            const dateString = date.toISOString().split('T')[0];
            data[dateString] = 0;
            labels.unshift(dateString);
        }
        
        notes.forEach(note => {
            if (note.createdAt) {
                const createdAt = new Date(note.createdAt);
                const dateString = createdAt.toISOString().split('T')[0];
                if (data[dateString] !== undefined) {
                    data[dateString]++;
                }
            }
        });

        const values = labels.map(label => data[label]);
        const maxVal = Math.max(...values, 1);

        return {
            labels: labels.map(l => new Date(l).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })),
            values,
            maxVal,
        };
    }, [notes]);

    useEffect(() => {
        const getStorageInfo = async () => {
            if (navigator.storage && navigator.storage.estimate) {
                try {
                    const estimate = await navigator.storage.estimate();
                    const used = new Blob([JSON.stringify(notes)]).size;
                    const quota = estimate.quota || 1;
                    setStorageInfo({
                        used,
                        quota,
                        percentage: (used / quota) * 100,
                    });
                } catch (error) {
                    console.error("Could not estimate storage:", error);
                    setStorageInfo(null);
                }
            }
        };
        getStorageInfo();
    }, [notes]);

    return (
        <div className="fixed inset-0 bg-black z-50 animate-fadeIn flex flex-col">
            <header className="sticky top-0 w-full bg-black/80 backdrop-blur-lg z-10 border-b border-gray-900 flex-shrink-0">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center h-16">
                        <button
                            type="button"
                            onClick={onBack}
                            className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-gray-500 transition-colors"
                            aria-label="Back to notes"
                        >
                            <ArrowLeftIcon className="h-6 w-6" />
                        </button>
                        <h1 className="text-lg font-semibold text-gray-200 ml-4">Note Insights</h1>
                    </div>
                </div>
            </header>
            <main className="flex-grow p-4 sm:p-6 lg:p-8 overflow-y-auto">
                <div className="max-w-4xl mx-auto space-y-8 pb-8">
                    <section aria-labelledby="overall-stats-title">
                        <h2 id="overall-stats-title" className="text-xl font-bold text-gray-200">Overall</h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                            <StatCard title="Total Notes" value={generalStats.totalNotes} />
                            <StatCard title="Words Written" value={generalStats.totalWords.toLocaleString()} />
                            <StatCard title="Characters" value={generalStats.totalCharacters.toLocaleString()} />
                            <StatCard title="Tokens (Est.)" value={generalStats.totalTokens.toLocaleString()} />
                        </div>
                    </section>

                    <section aria-labelledby="category-stats-title">
                        <h2 id="category-stats-title" className="text-xl font-bold text-gray-200">By Category</h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                            <StatCard title="Archived" value={categoryStats.archived} />
                            <StatCard title="Favorites" value={categoryStats.favorites} />
                            <StatCard title="Locked" value={categoryStats.locked} />
                            <StatCard title="In Trash" value={categoryStats.trash} />
                        </div>
                    </section>
                    
                    <section aria-labelledby="creation-history-title">
                        <div className="flex justify-between items-center flex-wrap gap-2">
                            <h2 id="creation-history-title" className="text-xl font-bold text-gray-200">Notes Created (Last 7 Days)</h2>
                        </div>
                        <div className="mt-4 bg-gray-900 p-4 rounded-lg border border-gray-800 h-64 flex items-end justify-around gap-2">
                            {chartData.values.map((value, index) => (
                                <div key={index} className="flex-1 flex flex-col items-center justify-end h-full pt-4" title={`${chartData.labels[index]}: ${value} note(s)`}>
                                    <div className="w-full h-full flex items-end">
                                        <div 
                                            className="w-full bg-gray-700 hover:bg-gray-600 rounded-t-md transition-all"
                                            style={{ height: `${(value / chartData.maxVal) * 100}%` }}
                                        />
                                    </div>
                                    <span className="text-xs text-gray-500 mt-2 truncate">{chartData.labels[index]}</span>
                                </div>
                            ))}
                        </div>
                    </section>

                    <section aria-labelledby="storage-usage-title">
                        <h2 id="storage-usage-title" className="text-xl font-bold text-gray-200">Storage Usage</h2>
                        <div className="mt-4 bg-gray-900 p-4 rounded-lg border border-gray-800">
                            {storageInfo ? (
                                <>
                                    <div className="flex justify-between text-sm text-gray-400 mb-2">
                                        <span>{formatBytes(storageInfo.used)} used</span>
                                        <span>{formatBytes(storageInfo.quota)} available</span>
                                    </div>
                                    <div className="w-full bg-gray-700 rounded-full h-2.5">
                                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${storageInfo.percentage.toFixed(2)}%` }}></div>
                                    </div>
                                </>
                            ) : (
                                <p className="text-gray-500 text-sm">Calculating storage usage...</p>
                            )}
                        </div>
                    </section>

                    {trashedNotes.length > 0 && (
                        <section aria-labelledby="trash-countdown-title">
                            <h2 id="trash-countdown-title" className="text-xl font-bold text-gray-200">Trash Countdown</h2>
                            <div className="mt-4 bg-gray-900 rounded-lg border border-gray-800">
                                <ul className="divide-y divide-gray-800">
                                    {trashedNotes.map(note => (
                                        <li key={note.id} className="p-4 relative">
                                            <p className="text-white truncate pr-4">{note.title}</p>
                                            {note.trashedAt && <TrashTimer trashedAt={note.trashedAt} />}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </section>
                    )}
                </div>
            </main>
        </div>
    );
};

export default InsightsPage;
