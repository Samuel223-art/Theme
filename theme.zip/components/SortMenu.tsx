
import React, { useRef, useEffect } from 'react';
import { Settings } from '../App';
import ChevronUpIcon from './icons/ChevronUpIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface SortMenuProps {
  settings: Settings;
  onSettingsChange: (newSettings: Partial<Settings>) => void;
  onClose: () => void;
}

const SortMenu: React.FC<SortMenuProps> = ({ settings, onSettingsChange, onClose }) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const { sortBy, sortOrder } = settings;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  const handleSortByChange = (newSortBy: Settings['sortBy']) => {
    onSettingsChange({ sortBy: newSortBy });
  };
  
  const handleSortOrderChange = (newSortOrder: Settings['sortOrder']) => {
    onSettingsChange({ sortOrder: newSortOrder });
  }

  const sortOptions: { value: Settings['sortBy']; label: string }[] = [
    { value: 'updatedAt', label: 'Last Updated' },
    { value: 'createdAt', label: 'Date Created' },
    { value: 'title', label: 'Title' },
  ];

  return (
    <div
      ref={menuRef}
      className="absolute top-16 right-4 sm:right-6 lg:right-8 w-64 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg shadow-2xl z-50 animate-fadeIn"
      role="menu"
      aria-orientation="vertical"
    >
        <div className="p-2">
            <div className="px-2 py-1 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Sort by</div>
            <div className="mt-1" role="group">
                {sortOptions.map(option => (
                    <button
                        key={option.value}
                        type="button"
                        onClick={() => handleSortByChange(option.value)}
                        className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${sortBy === option.value ? 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                        role="menuitemradio"
                        aria-checked={sortBy === option.value}
                    >
                        {option.label}
                    </button>
                ))}
            </div>
        </div>
        <div className="border-t border-gray-200 dark:border-gray-800 p-2">
             <div className="px-2 py-1 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Order</div>
              <div className="mt-1 flex items-center bg-gray-100 dark:bg-gray-800 p-1 rounded-lg" role="group">
                  <button
                    type="button"
                    onClick={() => handleSortOrderChange('asc')}
                    className={`flex-1 flex items-center justify-center gap-2 px-3 py-1 text-sm font-semibold rounded-md transition-colors ${sortOrder === 'asc' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700/50'}`}
                    role="menuitemradio"
                    aria-checked={sortOrder === 'asc'}
                  >
                    <ChevronUpIcon className="w-4 h-4" />
                    <span>Asc</span>
                  </button>
                   <button
                    type="button"
                    onClick={() => handleSortOrderChange('desc')}
                    className={`flex-1 flex items-center justify-center gap-2 px-3 py-1 text-sm font-semibold rounded-md transition-colors ${sortOrder === 'desc' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700/50'}`}
                    role="menuitemradio"
                    aria-checked={sortOrder === 'desc'}
                  >
                    <ChevronDownIcon className="w-4 h-4" />
                    <span>Desc</span>
                  </button>
              </div>
        </div>
    </div>
  );
};

export default SortMenu;
