
import React, { useState, useEffect, useCallback } from 'react';
import NavBar from './components/NavBar';
import NoteModal from './components/NoteModal';
import SearchIcon from './components/icons/SearchIcon';
import SearchPage from './components/SearchPage';
import EditorPage from './components/EditorPage';
import MultiSelectNavBar from './components/MultiSelectNavBar';
import MultiSelectBottomBar from './components/MultiSelectBottomBar';
import HomeMenu from './components/HomeMenu';
import NoteGrid from './components/NoteGrid';
import TrashIcon from './components/icons/TrashIcon';
import ArchiveIcon from './components/icons/ArchiveIcon';
import UnarchiveIcon from './components/icons/UnarchiveIcon';
import StarIcon from './components/icons/StarIcon';
import LockIcon from './components/icons/LockIcon';
import ShareIcon from './components/icons/ShareIcon';
import ConfirmationModal from './components/ConfirmationModal';
import RestoreIcon from './components/icons/RestoreIcon';
import VersionsPage from './components/VersionsPage';
import SetPasswordModal from './components/SetPasswordModal';
import PasswordPromptModal from './components/PasswordPromptModal';
import PdfPreviewModal from './components/PdfPreviewModal';
import PdfPage from './components/PdfPage';
import RenameModal from './components/RenameModal';
import InsightsPage from './components/InsightsPage';
import SettingsPage from './components/SettingsPage';
import PinIcon from './components/icons/PinIcon';
import SortMenu from './components/SortMenu';

export interface NoteVersion {
  title: string;
  content: string;
  savedAt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  isArchived?: boolean;
  isFavorite?: boolean;
  isLocked?: boolean;
  isTrashed?: boolean;
  trashedAt?: string;
  versions?: NoteVersion[];
  isPinned?: boolean;
}

export interface PdfFile {
  id: string;
  noteId: string;
  title: string;
  pdfDataUrl: string;
  createdAt: string;
}

export interface Settings {
  theme: 'light' | 'dark' | 'system';
  noteLayout: 'grid' | 'list';
  noteDensity: 'comfortable' | 'compact';
  editorFontSize: 'small' | 'medium' | 'large';
  editorFont: 'sans' | 'serif' | 'mono';
  showWordCount: boolean;
  sortBy: 'updatedAt' | 'createdAt' | 'title';
  sortOrder: 'asc' | 'desc';
  autoSaveEnabled: boolean;
}

const defaultSettings: Settings = {
  theme: 'system',
  noteLayout: 'grid',
  noteDensity: 'comfortable',
  editorFontSize: 'medium',
  editorFont: 'sans',
  showWordCount: true,
  sortBy: 'updatedAt',
  sortOrder: 'desc',
  autoSaveEnabled: true,
};

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [isNewNoteFlow, setIsNewNoteFlow] = useState(false);
  const [selectedNoteIds, setSelectedNoteIds] = useState<Set<string>>(new Set());
  const [isHomeMenuOpen, setIsHomeMenuOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [versionHistoryNote, setVersionHistoryNote] = useState<Note | null>(null);
  const [noteForPdf, setNoteForPdf] = useState<Note | null>(null);
  const [renameModalState, setRenameModalState] = useState<{isOpen: boolean; note: Note | null}>({isOpen: false, note: null});
  const [isSortMenuOpen, setIsSortMenuOpen] = useState(false);


  const [password, setPassword] = useState<string | null>(() => localStorage.getItem('x-note-password'));
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [showSetPasswordModal, setShowSetPasswordModal] = useState(false);
  const [passwordAttemptCallback, setPasswordAttemptCallback] = useState<(() => void) | null>(null);

  const [confirmationState, setConfirmationState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: (() => void) | null;
    confirmText: string;
    isDestructive: boolean;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: null,
    confirmText: 'Continue',
    isDestructive: false,
  });

  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const savedNotes = localStorage.getItem('x-notes');
      return savedNotes ? JSON.parse(savedNotes) : [];
    } catch (error) {
      console.error("Failed to parse notes from localStorage", error);
      return [];
    }
  });

  const [pdfs, setPdfs] = useState<PdfFile[]>(() => {
    try {
      const savedPdfs = localStorage.getItem('x-pdfs');
      return savedPdfs ? JSON.parse(savedPdfs) : [];
    } catch (error) {
      console.error("Failed to parse PDFs from localStorage", error);
      return [];
    }
  });
  
  const [settings, setSettings] = useState<Settings>(() => {
    try {
      const savedSettings = localStorage.getItem('x-note-settings');
      return savedSettings ? { ...defaultSettings, ...JSON.parse(savedSettings) } : defaultSettings;
    } catch (error) {
      console.error("Failed to parse settings from localStorage", error);
      return defaultSettings;
    }
  });
  
  useEffect(() => {
    localStorage.setItem('x-note-settings', JSON.stringify(settings));
    // Handle theme change
    if (settings.theme === 'dark' || (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('x-notes', JSON.stringify(notes));
  }, [notes]);
  
  useEffect(() => {
    localStorage.setItem('x-pdfs', JSON.stringify(pdfs));
  }, [pdfs]);

  useEffect(() => {
    if (password) {
        localStorage.setItem('x-note-password', password);
    } else {
        localStorage.removeItem('x-note-password');
    }
  }, [password]);

  const handleOpenModal = () => setIsModalOpen(true);
  const handleCloseModal = () => setIsModalOpen(false);
  const handleOpenSearch = () => setIsSearching(true);
  const handleCloseSearch = () => setIsSearching(false);
  const handleBackFromEditor = () => {
    setEditingNote(null);
    setIsNewNoteFlow(false);
  };
  const handleOpenHomeMenu = () => setIsHomeMenuOpen(true);
  const handleCloseHomeMenu = () => setIsHomeMenuOpen(false);

  const handleSetNewPassword = (newPassword: string) => {
    setPassword(newPassword);
    setShowSetPasswordModal(false);
    if (passwordAttemptCallback) {
        passwordAttemptCallback();
        setPasswordAttemptCallback(null);
    }
  };
  
  const handleRemovePassword = () => {
    const confirmAction = () => {
      setPassword(null);
      // Unlock all notes
      setNotes(prev => prev.map(n => n.isLocked ? { ...n, isLocked: false } : n));
      alert('Password removed and all notes have been unlocked.');
    };
    setConfirmationState({
        isOpen: true,
        title: 'Remove Password?',
        message: 'Are you sure you want to remove your password? All locked notes will be unlocked. This action cannot be undone.',
        onConfirm: confirmAction,
        confirmText: 'Remove Password',
        isDestructive: true,
      });
  };

  const handlePasswordPromptSubmit = (attempt: string) => {
      if (attempt === password) {
          setShowPasswordPrompt(false);
          if (passwordAttemptCallback) {
              passwordAttemptCallback();
              setPasswordAttemptCallback(null);
          }
      } else {
          alert('Incorrect password');
      }
  };

  const handleNavigate = (page: string) => {
      handleCloseHomeMenu();
      if (page === 'locked') {
          if (currentPage === 'locked') {
              return; // Already on the page, do nothing.
          }
          
          const successAction = () => setCurrentPage('locked');
          setPasswordAttemptCallback(() => successAction);

          if (!password) {
              setShowSetPasswordModal(true);
          } else {
              setShowPasswordPrompt(true);
          }
      } else {
          setCurrentPage(page);
      }
  };
  
  const handleBackFromSecondaryPage = () => {
    setCurrentPage('home');
  };

  const handleOpenPdfModal = (note: Note) => {
    setNoteForPdf(note);
  };
  const handleClosePdfModal = () => {
      setNoteForPdf(null);
  };
  
  const handleSavePdf = (noteId: string, title: string, pdfDataUrl: string) => {
    const newPdf: PdfFile = {
        id: `pdf_${Date.now()}`,
        noteId,
        title,
        pdfDataUrl,
        createdAt: new Date().toISOString(),
    };
    setPdfs(prevPdfs => [newPdf, ...prevPdfs]);
    handleClosePdfModal();
    setCurrentPage('pdfs'); // Navigate to PDF page after saving
  };


  const handleOpenSetPasswordModal = () => {
      setShowSetPasswordModal(true);
      handleCloseHomeMenu();
  };

  const handleCloseConfirmation = () => {
    setConfirmationState({ ...confirmationState, isOpen: false });
  };
  
  const handleConfirm = () => {
    if (confirmationState.onConfirm) {
      confirmationState.onConfirm();
    }
    handleCloseConfirmation();
  };

  const handleOpenRenameModal = (noteToRename: Note) => {
    setRenameModalState({ isOpen: true, note: noteToRename });
  };
  const handleCloseRenameModal = () => {
    setRenameModalState({ isOpen: false, note: null });
  };
  const handleConfirmRename = (noteId: string, newTitle: string) => {
    const now = new Date().toISOString();
    setNotes(prevNotes => prevNotes.map(note => 
      note.id === noteId ? { ...note, title: newTitle, updatedAt: now } : note
    ));
    setEditingNote(prevNote => 
      prevNote && prevNote.id === noteId ? { ...prevNote, title: newTitle, updatedAt: now } : prevNote
    );
    handleCloseRenameModal();
  };
  
  const handleSettingsChange = (newSettings: Partial<Settings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };
  
  const handleExportData = () => {
    const data = {
      notes,
      pdfs,
      settings,
      timestamp: new Date().toISOString(),
    };
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `x-note-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const result = event.target?.result;
          if (typeof result !== 'string') throw new Error('Invalid file content');
          const data = JSON.parse(result);

          if (data.notes || data.pdfs || data.settings) {
            setConfirmationState({
                isOpen: true,
                title: 'Import Data?',
                message: 'This will overwrite your current notes, PDFs, and settings. Are you sure you want to continue?',
                onConfirm: () => {
                    setNotes(data.notes || []);
                    setPdfs(data.pdfs || []);
                    setSettings(prev => ({ ...prev, ...(data.settings || {}) }));
                    alert('Data imported successfully!');
                },
                confirmText: 'Import',
                isDestructive: true,
            });
          } else {
            throw new Error('Invalid backup file structure.');
          }
        } catch (error) {
          console.error("Failed to import data:", error);
          alert('Failed to import data. The file might be corrupted or in the wrong format.');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const handleClearAllData = () => {
    setConfirmationState({
        isOpen: true,
        title: 'Clear All Data?',
        message: 'This will permanently delete all your notes, PDFs, and settings. This action cannot be undone.',
        onConfirm: () => {
            localStorage.removeItem('x-notes');
            localStorage.removeItem('x-pdfs');
            localStorage.removeItem('x-note-settings');
            localStorage.removeItem('x-note-password');
            setNotes([]);
            setPdfs([]);
            setSettings(defaultSettings);
            setPassword(null);
            alert('All data has been cleared.');
        },
        confirmText: 'Delete Everything',
        isDestructive: true,
    });
  };

  const handleCreateNote = (title: string) => {
    const newNote: Note = {
      id: `note_${Date.now()}`,
      title,
      content: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isArchived: false,
      isFavorite: false,
      isLocked: false,
      isTrashed: false,
      versions: [],
      isPinned: false,
    };
    setNotes(prevNotes => [newNote, ...prevNotes]);
    setEditingNote(newNote);
    setIsNewNoteFlow(true);
    handleCloseModal();
  };

  const handleAutoUpdateNote = useCallback((updatedNote: Note) => {
    const now = new Date().toISOString();
    setNotes(notes => notes.map(note => 
      note.id === updatedNote.id 
        ? { ...note, content: updatedNote.content, title: updatedNote.title, updatedAt: now } 
        : note
    ));
    // Also update the editingNote state to ensure consistency without closing the editor
    setEditingNote(prev => (prev && prev.id === updatedNote.id ? { ...prev, ...updatedNote, updatedAt: now } : prev));
  }, []);

  const handleSaveNote = useCallback((updatedNote: Note) => {
    const now = new Date().toISOString();
    const originalNote = notes.find(n => n.id === updatedNote.id);

    if (originalNote) {
      if (originalNote.content !== updatedNote.content || originalNote.title !== updatedNote.title) {
        const previousVersion: NoteVersion = {
          title: originalNote.title,
          content: originalNote.content,
          savedAt: originalNote.updatedAt,
        };
        const newVersions = [previousVersion, ...(originalNote.versions || [])];
        
        setNotes(notes.map(note =>
          note.id === updatedNote.id 
            ? { ...updatedNote, updatedAt: now, versions: newVersions } 
            : note
        ));
      } else {
         setNotes(notes.map(note =>
          note.id === updatedNote.id ? { ...updatedNote, updatedAt: now } : note
        ));
      }
    }
    setEditingNote(null);
  }, [notes]);

  const handleShowVersions = useCallback((note: Note) => {
    setVersionHistoryNote(note);
  }, []);
  
  const handleCloseVersions = () => {
    setVersionHistoryNote(null);
  };
  
  const handleRollbackVersion = (noteId: string, versionToRestore: NoteVersion) => {
    const noteToUpdate = notes.find(n => n.id === noteId);
    if (!noteToUpdate) return;
  
    // Save the current state before rolling back, to prevent data loss
    const currentVersion: NoteVersion = {
      title: noteToUpdate.title,
      content: noteToUpdate.content,
      savedAt: noteToUpdate.updatedAt,
    };
    const newVersions = [currentVersion, ...(noteToUpdate.versions || [])];
  
    const rolledBackNote: Note = {
      ...noteToUpdate,
      title: versionToRestore.title,
      content: versionToRestore.content,
      updatedAt: new Date().toISOString(),
      versions: newVersions,
    };
  
    setNotes(notes.map(n => (n.id === noteId ? rolledBackNote : n)));
    setEditingNote(rolledBackNote); // Update the editor with the rolled-back content
    setVersionHistoryNote(null); // Close the versions page
  };
  
  const handleDeleteVersion = (noteId: string, versionToDelete: NoteVersion) => {
    const confirmAction = () => {
      setNotes(prevNotes =>
        prevNotes.map(note => {
          if (note.id === noteId) {
            const newVersions = (note.versions || []).filter(
              v => v.savedAt !== versionToDelete.savedAt
            );
            const updatedNote = { ...note, versions: newVersions };
            
            // Also update the note being viewed in the versions page
            setVersionHistoryNote(updatedNote);
            
            return updatedNote;
          }
          return note;
        })
      );
    };
  
    setConfirmationState({
      isOpen: true,
      title: 'Delete this version?',
      message: 'This action is permanent and cannot be undone.',
      onConfirm: confirmAction,
      confirmText: 'Delete',
      isDestructive: true,
    });
  };


  const handleNoteLongPress = (noteId: string) => {
    setSelectedNoteIds(prev => {
      const newSet = new Set(prev);
      newSet.add(noteId);
      return newSet;
    });
  };

  const handleNotePress = (note: Note) => {
    if (selectedNoteIds.size > 0) {
      setSelectedNoteIds(prev => {
        const newSet = new Set(prev);
        if (newSet.has(note.id)) {
          newSet.delete(note.id);
        } else {
          newSet.add(note.id);
        }
        return newSet;
      });
    } else {
      setEditingNote(note);
      setIsNewNoteFlow(false);
    }
  };

  const handleCancelMultiSelect = () => {
    setSelectedNoteIds(new Set());
  };

  const handleSelectAll = (notesToSelect: Note[]) => {
    if (selectedNoteIds.size === notesToSelect.length) {
      setSelectedNoteIds(new Set());
    } else {
      setSelectedNoteIds(new Set(notesToSelect.map(n => n.id)));
    }
  };
  
  // Swipe Actions (no confirmation)
  const trashNoteById = (noteId: string) => {
    const now = new Date().toISOString();
    setNotes(prev => prev.map(n => n.id === noteId ? { ...n, isTrashed: true, trashedAt: now, isArchived: false, isFavorite: false, isLocked: false } : n));
  };
  
  const deletePermanentlyById = (noteId: string) => {
    setNotes(prev => prev.filter(n => n.id !== noteId));
  };
  
  const archiveNoteById = (noteId: string, archive: boolean) => {
    setNotes(prev => prev.map(n => {
      if (n.id === noteId) {
        const updatedNote = { ...n, isArchived: archive, isLocked: false };
        if (archive) updatedNote.isFavorite = false;
        return updatedNote;
      }
      return n;
    }));
  };
  
  const restoreNoteById = (noteId: string) => {
    setNotes(prev => prev.map(n => n.id === noteId ? { ...n, isTrashed: false, trashedAt: undefined } : n));
  };

  const handleTrashSelected = () => {
    const confirmAction = () => {
      const now = new Date().toISOString();
      setNotes(prevNotes => prevNotes.map(note => {
        if (selectedNoteIds.has(note.id)) {
          return {
            ...note,
            isTrashed: true,
            trashedAt: now,
            isArchived: false,
            isFavorite: false,
            isLocked: false,
          };
        }
        return note;
      }));
      handleCancelMultiSelect();
    };

    setConfirmationState({
      isOpen: true,
      title: `Move ${selectedNoteIds.size} Note(s) to Trash?`,
      message: 'You can restore them from the trash within 7 days.',
      onConfirm: confirmAction,
      confirmText: 'Move to Trash',
      isDestructive: true,
    });
  };

  const handleDeletePermanentlySelected = () => {
     const confirmAction = () => {
      setNotes(prevNotes => prevNotes.filter(note => !selectedNoteIds.has(note.id)));
      handleCancelMultiSelect();
    };

    setConfirmationState({
      isOpen: true,
      title: `Permanently Delete ${selectedNoteIds.size} Note(s)?`,
      message: 'Are you sure? This action cannot be undone.',
      onConfirm: confirmAction,
      confirmText: 'Delete',
      isDestructive: true,
    });
  };

  const handleRestoreSelected = () => {
    setNotes(prevNotes => prevNotes.map(note => {
      if(selectedNoteIds.has(note.id)) {
        return { ...note, isTrashed: false, trashedAt: undefined };
      }
      return note;
    }));
    handleCancelMultiSelect();
  }

  const handleRestoreNote = (noteId: string) => {
    setNotes(prevNotes => prevNotes.map(note => {
      if(note.id === noteId) {
        return { ...note, isTrashed: false, trashedAt: undefined };
      }
      return note;
    }));
    handleBackFromEditor();
  }

  const handleDeleteAllTrash = () => {
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.filter(note => !note.isTrashed));
    };

    setConfirmationState({
      isOpen: true,
      title: `Empty Trash?`,
      message: 'All notes in the trash will be permanently deleted. This action cannot be undone.',
      onConfirm: confirmAction,
      confirmText: 'Empty Trash',
      isDestructive: true,
    });
  };
  
  const handleToggleArchiveSelected = (archive: boolean) => {
    const actionText = archive ? 'Archive' : 'Unarchive';
    let message = `The selected note(s) will be moved ${archive ? 'to' : 'from'} the archive.`;
    
    if (archive) {
      const notesToArchiveAreFavorites = Array.from(selectedNoteIds).some(id => notes.find(n => n.id === id)?.isFavorite);
      if (notesToArchiveAreFavorites) {
        message += ' Any favorited notes will be removed from favorites.';
      }
    }
     
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.map(note => {
        if (selectedNoteIds.has(note.id)) {
          const updatedNote = { ...note, isArchived: archive, isLocked: false };
          if (archive) {
            updatedNote.isFavorite = false;
          }
          return updatedNote;
        }
        return note;
      }));
      handleCancelMultiSelect();
    };

    setConfirmationState({
      isOpen: true,
      title: `${actionText} ${selectedNoteIds.size} Note(s)?`,
      message: message,
      onConfirm: confirmAction,
      confirmText: actionText,
      isDestructive: false,
    });
  }

  const handleToggleFavoriteSelected = () => {
    const allSelectedAreFavorites = Array.from(selectedNoteIds).every(id => notes.find(n => n.id === id)?.isFavorite);
    const actionText = allSelectedAreFavorites ? 'Remove from' : 'Add to';
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.map(note => selectedNoteIds.has(note.id) ? {...note, isFavorite: !allSelectedAreFavorites, isLocked: false} : note));
      handleCancelMultiSelect();
    };
    
    setConfirmationState({
      isOpen: true,
      title: `${actionText} Favorites?`,
      message: `The selected note(s) will be ${allSelectedAreFavorites ? 'removed from' : 'added to'} your favorites.`,
      onConfirm: confirmAction,
      confirmText: 'Continue',
      isDestructive: false,
    });
  }
  
  const handleToggleLockSelected = () => {
    const allSelectedAreLocked = Array.from(selectedNoteIds).every(id => notes.find(n => n.id === id)?.isLocked);
    const actionText = allSelectedAreLocked ? 'Unlock' : 'Lock';
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.map(note => {
        if (selectedNoteIds.has(note.id)) {
          return {...note, isLocked: !allSelectedAreLocked, isArchived: false, isFavorite: false };
        }
        return note;
      }));
      handleCancelMultiSelect();
    };

    setConfirmationState({
      isOpen: true,
      title: `${actionText} ${selectedNoteIds.size} Note(s)?`,
      message: `This will ${actionText.toLowerCase()} the selected note(s) and remove them from archives or favorites.`,
      onConfirm: confirmAction,
      confirmText: actionText,
      isDestructive: false,
    });
  };

  const handleTogglePinSelected = () => {
    const allSelectedArePinned = Array.from(selectedNoteIds).every(id => notes.find(n => n.id === id)?.isPinned);
    const actionText = allSelectedArePinned ? 'Unpin' : 'Pin';
    const confirmAction = () => {
        setNotes(prevNotes => prevNotes.map(note =>
            selectedNoteIds.has(note.id) ? { ...note, isPinned: !allSelectedArePinned } : note
        ));
        handleCancelMultiSelect();
    };
    setConfirmationState({
        isOpen: true,
        title: `${actionText} ${selectedNoteIds.size} Note(s)?`,
        message: `This will ${actionText.toLowerCase()} the selected note(s).`,
        onConfirm: confirmAction,
        confirmText: actionText,
        isDestructive: false,
    });
  };

  const handleTrashNote = (noteId: string) => {
    const confirmAction = () => {
      const now = new Date().toISOString();
      setNotes(prevNotes => prevNotes.map(note => {
        if (note.id === noteId) {
          return {
            ...note,
            isTrashed: true,
            trashedAt: now,
            isArchived: false,
            isFavorite: false,
            isLocked: false,
          };
        }
        return note;
      }));
      setEditingNote(null);
    };

    setConfirmationState({
      isOpen: true,
      title: 'Move Note to Trash?',
      message: 'You can restore it from the trash within 7 days.',
      onConfirm: confirmAction,
      confirmText: 'Move to Trash',
      isDestructive: true,
    });
  };

  const handleDeletePermanentlyNote = (noteId: string) => {
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.filter(note => note.id !== noteId));
      setEditingNote(null);
    };

    setConfirmationState({
      isOpen: true,
      title: 'Permanently Delete Note?',
      message: 'Are you sure? This action cannot be undone.',
      onConfirm: confirmAction,
      confirmText: 'Delete',
      isDestructive: true,
    });
  }

  const handleToggleArchiveNote = (noteId: string, archive: boolean) => {
    const noteToArchive = notes.find(n => n.id === noteId);
    if (!noteToArchive) return;
    
    const actionText = archive ? 'Archive' : 'Unarchive';
    let message = `The note will be moved ${archive ? 'to' : 'from'} the archive.`;
    
    if (archive && noteToArchive.isFavorite) {
        message += ' This note will also be removed from favorites.';
    }

    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.map(note => {
        if (note.id === noteId) {
          const updatedNote = { ...note, isArchived: archive, isLocked: false };
          if (archive) {
            updatedNote.isFavorite = false;
          }
          return updatedNote;
        }
        return note;
      }));
      setEditingNote(null);
    };

    setConfirmationState({
      isOpen: true,
      title: `${actionText} Note?`,
      message: message,
      onConfirm: confirmAction,
      confirmText: actionText,
      isDestructive: false,
    });
  }

  const handleToggleFavoriteNote = (noteId: string) => {
    const noteToToggle = notes.find(n => n.id === noteId);
    if (!noteToToggle) return;

    const isCurrentlyFavorite = noteToToggle.isFavorite;
    const actionText = isCurrentlyFavorite ? 'Remove from' : 'Add to';
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.map(note => note.id === noteId ? { ...note, isFavorite: !isCurrentlyFavorite, isLocked: false } : note));
      setEditingNote(prev => prev ? { ...prev, isFavorite: !isCurrentlyFavorite } : null);
    };
    
    setConfirmationState({
      isOpen: true,
      title: `${actionText} Favorites?`,
      message: `The note will be ${isCurrentlyFavorite ? 'removed from' : 'added to'} your favorites.`,
      onConfirm: confirmAction,
      confirmText: 'Continue',
      isDestructive: false,
    });
  }

  const handleToggleLockNote = (noteId: string) => {
    const noteToToggle = notes.find(n => n.id === noteId);
    if (!noteToToggle) return;

    const isCurrentlyLocked = noteToToggle.isLocked;
    const actionText = isCurrentlyLocked ? 'Unlock' : 'Lock';
    const confirmAction = () => {
      setNotes(prevNotes => prevNotes.map(note => note.id === noteId ? { ...note, isLocked: !isCurrentlyLocked, isArchived: false, isFavorite: false } : note));
      setEditingNote(prev => prev ? { ...prev, isLocked: !isCurrentlyLocked, isArchived: false, isFavorite: false } : null);
    };
    
    setConfirmationState({
      isOpen: true,
      title: `${actionText} Note?`,
      message: `The note will be ${isCurrentlyLocked ? 'unlocked' : 'locked'}. When locking a note, it will be removed from favorites and archives.`,
      onConfirm: confirmAction,
      confirmText: 'Continue',
      isDestructive: false,
    });
  }
  
  const handleTogglePinNote = (noteId: string) => {
    const noteToToggle = notes.find(n => n.id === noteId);
    if (!noteToToggle) return;

    setNotes(prevNotes => prevNotes.map(note => note.id === noteId ? { ...note, isPinned: !note.isPinned } : note));
    setEditingNote(prev => prev ? { ...prev, isPinned: !prev.isPinned } : null);
  };
  
  const handleShareSelected = () => { console.log('Sharing note:', selectedNoteIds); handleCancelMultiSelect(); };

  const isMultiSelectMode = selectedNoteIds.size > 0;

  let pageTitle: string;
  let currentNotes: Note[];
  
  const getSortedNotes = (notesToSort: Note[]) => {
    const sorted = [...notesToSort].sort((a, b) => {
      const order = settings.sortOrder === 'asc' ? 1 : -1;
      switch (settings.sortBy) {
        case 'title':
          return a.title.localeCompare(b.title) * order;
        case 'createdAt':
          return (new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()) * order;
        case 'updatedAt':
        default:
          return (new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime()) * order;
      }
    });

    return sorted.sort((a, b) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0));
  };

  switch (currentPage) {
    case 'archive':
      pageTitle = 'Archive';
      currentNotes = getSortedNotes(notes.filter(n => n.isArchived && !n.isTrashed));
      break;
    case 'favorites':
      pageTitle = 'Favorites';
      currentNotes = getSortedNotes(notes.filter(n => n.isFavorite && !n.isArchived && !n.isTrashed));
      break;
    case 'trash':
      pageTitle = 'Trash';
      currentNotes = notes.filter(n => n.isTrashed); // No sorting for trash
      break;
    case 'locked':
      pageTitle = 'Locked Notes';
      currentNotes = getSortedNotes(notes.filter(n => n.isLocked && !n.isArchived && !n.isTrashed));
      break;
    case 'pdfs':
      pageTitle = 'PDFs';
      currentNotes = [];
      break;
    case 'insights':
    case 'settings':
      pageTitle = currentPage.charAt(0).toUpperCase() + currentPage.slice(1);
      currentNotes = [];
      break;
    default:
      pageTitle = 'All Notes';
      currentNotes = getSortedNotes(notes.filter(n => !n.isArchived && !n.isTrashed && !n.isLocked));
      break;
  }
  
  let multiSelectActions;
  const allSelectedArePinned = Array.from(selectedNoteIds).every(id => notes.find(n => n.id === id)?.isPinned);

  if (currentPage === 'trash') {
    multiSelectActions = [
      { name: 'Restore', icon: <RestoreIcon className="h-6 w-6" />, handler: handleRestoreSelected, show: true },
      { name: 'Delete', icon: <TrashIcon className="h-6 w-6" />, handler: handleDeletePermanentlySelected, show: true },
    ];
  } else if (currentPage === 'locked') {
    multiSelectActions = [
        { name: 'Unlock', icon: <LockIcon className="h-6 w-6" />, handler: handleToggleLockSelected, show: true },
        { name: 'Delete', icon: <TrashIcon className="h-6 w-6" />, handler: handleDeletePermanentlySelected, show: true },
    ];
  } else {
    multiSelectActions = [
      { name: 'Delete', icon: <TrashIcon className="h-6 w-6" />, handler: handleTrashSelected, show: true },
      ...(currentPage === 'archive'
        ? [{ name: 'Unarchive', icon: <UnarchiveIcon className="h-6 w-6" />, handler: () => handleToggleArchiveSelected(false), show: true }]
        : [{ name: 'Archive', icon: <ArchiveIcon className="h-6 w-6" />, handler: () => handleToggleArchiveSelected(true), show: true }]),
      { name: 'Favourite', icon: <StarIcon className="h-6 w-6" />, handler: handleToggleFavoriteSelected, show: currentPage !== 'archive' },
      { name: 'Lock', icon: <LockIcon className="h-6 w-6" />, handler: handleToggleLockSelected, show: currentPage !== 'archive' },
      { name: allSelectedArePinned ? 'Unpin' : 'Pin', icon: <PinIcon className="h-6 w-6" />, handler: handleTogglePinSelected, show: currentPage !== 'archive' },
      { name: 'Share', icon: <ShareIcon className="h-6 w-6" />, handler: handleShareSelected, show: selectedNoteIds.size === 1 },
    ];
  }
  
  const showSortButton = ['home', 'archive', 'favorites', 'locked'].includes(currentPage) && currentNotes.length > 0;
  
  let swipeRightAction, swipeLeftAction;
  if (currentPage === 'trash') {
      swipeRightAction = { action: restoreNoteById, icon: <RestoreIcon className="h-6 w-6 text-white" />, color: 'bg-blue-600' };
      swipeLeftAction = { action: deletePermanentlyById, icon: <TrashIcon className="h-6 w-6 text-white" />, color: 'bg-red-700' };
  } else if (currentPage === 'archive') {
      swipeRightAction = { action: (id: string) => archiveNoteById(id, false), icon: <UnarchiveIcon className="h-6 w-6 text-white" />, color: 'bg-green-600' };
      swipeLeftAction = { action: trashNoteById, icon: <TrashIcon className="h-6 w-6 text-white" />, color: 'bg-red-600' };
  } else if (currentPage !== 'locked') {
      swipeRightAction = { action: (id: string) => archiveNoteById(id, true), icon: <ArchiveIcon className="h-6 w-6 text-white" />, color: 'bg-green-600' };
      swipeLeftAction = { action: trashNoteById, icon: <TrashIcon className="h-6 w-6 text-white" />, color: 'bg-red-600' };
  }

  return (
    <div className="min-h-screen font-sans bg-gray-100 dark:bg-black text-gray-900 dark:text-white">
      {isMultiSelectMode ? (
        <MultiSelectNavBar
          selectedCount={selectedNoteIds.size}
          totalCount={currentNotes.length}
          onCancel={handleCancelMultiSelect}
          onSelectAll={() => handleSelectAll(currentNotes)}
        />
      ) : (
        <NavBar
          onAddClick={handleOpenModal}
          onMenuClick={handleOpenHomeMenu}
          onSortClick={() => setIsSortMenuOpen(!isSortMenuOpen)}
          showAddButton={currentPage === 'home'}
          showSortButton={showSortButton}
          actionText={currentPage === 'trash' && currentNotes.length > 0 ? 'Empty Trash' : undefined}
          onActionClick={currentPage === 'trash' ? handleDeleteAllTrash : undefined}
        />
      )}
      
      {isSortMenuOpen && showSortButton && (
        <SortMenu
            settings={settings}
            onSettingsChange={handleSettingsChange}
            onClose={() => setIsSortMenuOpen(false)}
        />
      )}

      <main className={`p-4 sm:p-6 lg:p-8 transition-all duration-300 ${isMultiSelectMode ? 'pb-24' : ''}`}>
        {(currentPage === 'home' || currentPage === 'trash' && currentNotes.length === 0) && (
          <div className={`max-w-3xl mx-auto mb-8 ${isMultiSelectMode ? 'pointer-events-none opacity-50' : ''}`}>
            {currentPage === 'home' && (
              <button
                type="button"
                onClick={handleOpenSearch}
                className="w-full flex items-center text-left space-x-3 px-4 py-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-400 dark:focus:ring-gray-600 transition-colors"
                aria-label="Search notes"
              >
                <SearchIcon className="h-5 w-5" />
                <span>Search notes...</span>
              </button>
            )}
          </div>
        )}
        
        <div className="max-w-7xl mx-auto">
          {currentPage !== 'home' && currentPage !== 'insights' && currentPage !== 'settings' && (
             <h1 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-200">{pageTitle}</h1>
          )}
           {currentPage === 'pdfs' ? (
            <PdfPage pdfs={pdfs} />
           ) : currentPage === 'insights' || currentPage === 'settings' ? (
             null
           ) : (
            <NoteGrid 
              notes={currentNotes}
              handleNotePress={handleNotePress}
              handleNoteLongPress={handleNoteLongPress}
              selectedNoteIds={selectedNoteIds}
              layout={settings.noteLayout}
              density={settings.noteDensity}
              swipeLeftAction={swipeLeftAction}
              swipeRightAction={swipeRightAction}
            />
           )}
        </div>
      </main>

      {currentPage === 'insights' && (
        <InsightsPage
            notes={notes}
            onBack={handleBackFromSecondaryPage}
        />
      )}
      
      {currentPage === 'settings' && (
        <SettingsPage
          onBack={handleBackFromSecondaryPage}
          settings={settings}
          onSettingsChange={handleSettingsChange}
          onExportData={handleExportData}
          onImportData={handleImportData}
          onClearAllData={handleClearAllData}
          onSetPassword={handleOpenSetPasswordModal}
          onRemovePassword={handleRemovePassword}
          isPasswordSet={!!password}
        />
      )}

      <NoteModal 
        isOpen={isModalOpen} 
        onClose={handleCloseModal} 
        onCreate={handleCreateNote}
      />
      {isSearching && (
        <SearchPage
          notes={notes.filter(n => !n.isTrashed)}
          onBack={handleCloseSearch}
          onNoteSelect={(note) => {
            setEditingNote(note);
            setIsNewNoteFlow(false);
            handleCloseSearch();
          }}
          layout={settings.noteLayout}
          density={settings.noteDensity}
        />
      )}
      {editingNote && !versionHistoryNote && (
        <EditorPage
          note={editingNote}
          onBack={handleBackFromEditor}
          onSave={handleSaveNote}
          onAutoUpdate={handleAutoUpdateNote}
          onTrash={() => handleTrashNote(editingNote.id)}
          onDeletePermanently={() => handleDeletePermanentlyNote(editingNote.id)}
          onToggleArchive={() => handleToggleArchiveNote(editingNote.id, !editingNote.isArchived)}
          onToggleFavorite={() => handleToggleFavoriteNote(editingNote.id)}
          onToggleLock={() => handleToggleLockNote(editingNote.id)}
          onTogglePin={() => handleTogglePinNote(editingNote.id)}
          onShowVersions={() => handleShowVersions(editingNote)}
          onConvertToPdf={() => handleOpenPdfModal(editingNote)}
          onOpenRenameModal={() => handleOpenRenameModal(editingNote)}
          isTrashNote={currentPage === 'trash'}
          isNewNote={isNewNoteFlow}
          onRestore={() => handleRestoreNote(editingNote.id)}
          onUnsavedChanges={(callback) => {
            setConfirmationState({
                isOpen: true,
                title: 'Discard Changes?',
                message: 'You have unsaved changes. Are you sure you want to discard them?',
                onConfirm: callback,
                confirmText: 'Discard',
                isDestructive: true,
            });
          }}
          editorFont={settings.editorFont}
          editorFontSize={settings.editorFontSize}
          showWordCount={settings.showWordCount}
          autoSaveEnabled={settings.autoSaveEnabled}
        />
      )}
      
      {versionHistoryNote && (
        <VersionsPage 
          note={versionHistoryNote} 
          onBack={handleCloseVersions}
          onRollback={handleRollbackVersion}
          onDelete={handleDeleteVersion}
        />
      )}

      {noteForPdf && (
        <PdfPreviewModal
            isOpen={!!noteForPdf}
            onClose={handleClosePdfModal}
            onSave={handleSavePdf}
            note={noteForPdf}
        />
      )}

      {renameModalState.isOpen && renameModalState.note && (
        <RenameModal
          isOpen={renameModalState.isOpen}
          onClose={handleCloseRenameModal}
          onConfirmRename={handleConfirmRename}
          note={renameModalState.note}
        />
      )}

      <HomeMenu 
        isOpen={isHomeMenuOpen} 
        onClose={handleCloseHomeMenu} 
        onNavigate={handleNavigate} 
        currentPage={currentPage}
        isPasswordSet={!!password}
        onSetPassword={handleOpenSetPasswordModal}
      />
      
      <ConfirmationModal
        isOpen={confirmationState.isOpen}
        onClose={handleCloseConfirmation}
        onConfirm={handleConfirm}
        title={confirmationState.title}
        message={confirmationState.message}
        confirmText={confirmationState.confirmText}
        isDestructive={confirmationState.isDestructive}
      />

      <PasswordPromptModal
        isOpen={showPasswordPrompt}
        onClose={() => setShowPasswordPrompt(false)}
        onSubmit={handlePasswordPromptSubmit}
      />
      
      <SetPasswordModal 
        isOpen={showSetPasswordModal} 
        onClose={() => setShowSetPasswordModal(false)}
        onSetPassword={handleSetNewPassword}
      />

      {isMultiSelectMode && currentPage !== 'pdfs' && (
        <MultiSelectBottomBar
          actions={multiSelectActions}
        />
      )}
    </div>
  );
};

export default App;
