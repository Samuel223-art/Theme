const CACHE_NAME = 'x-note-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/index.css',
  '/index.tsx',
  '/App.tsx',
  '/logo.svg',
  '/manifest.json',
  '/components/BottomToolbar.tsx',
  '/components/ConfirmationModal.tsx',
  '/components/EditorMenu.tsx',
  '/components/EditorPage.tsx',
  '/components/FindBar.tsx',
  '/components/HomeMenu.tsx',
  '/components/InsightsPage.tsx',
  '/components/MultiSelectBottomBar.tsx',
  '/components/MultiSelectNavBar.tsx',
  '/components/NavBar.tsx',
  '/components/NoteCard.tsx',
  '/components/NoteGrid.tsx',
  '/components/NoteModal.tsx',
  '/components/PasswordPromptModal.tsx',
  '/components/PdfCard.tsx',
  '/components/PdfPage.tsx',
  '/components/PdfPreviewModal.tsx',
  '/components/RenameModal.tsx',
  '/components/SearchPage.tsx',
  '/components/SetPasswordModal.tsx',
  '/components/SettingsPage.tsx',
  '/components/SortMenu.tsx',
  '/components/TrashTimer.tsx',
  '/components/VersionsPage.tsx',
  '/components/icons/AlignCenterIcon.tsx',
  '/components/icons/AlignLeftIcon.tsx',
  '/components/icons/AlignRightIcon.tsx',
  '/components/icons/ArchiveIcon.tsx',
  '/components/icons/ArrowLeftIcon.tsx',
  '/components/icons/BackupIcon.tsx',
  '/components/icons/BlockquoteIcon.tsx',
  '/components/icons/BoldIcon.tsx',
  '/components/icons/CheckCircleIcon.tsx',
  '/components/icons/ChevronDownIcon.tsx',
  '/components/icons/ChevronUpIcon.tsx',
  '/components/icons/CodeIcon.tsx',
  '/components/icons/DesktopIcon.tsx',
  '/components/icons/EditIcon.tsx',
  '/components/icons/EllipsisVerticalIcon.tsx',
  '/components/icons/ExportIcon.tsx',
  '/components/icons/Heading1Icon.tsx',
  '/components/icons/Heading2Icon.tsx',
  '/components/icons/HighlightIcon.tsx',
  '/components/icons/HistoryIcon.tsx',
  '/components/icons/HomeIcon.tsx',
  '/components/icons/HorizontalRuleIcon.tsx',
  '/components/icons/IconProps.ts',
  '/components/icons/ImportIcon.tsx',
  '/components/icons/IndentIcon.tsx',
  '/components/icons/InsightsIcon.tsx',
  '/components/icons/KeyIcon.tsx',
  '/components/icons/LayoutGridIcon.tsx',
  '/components/icons/LayoutListIcon.tsx',
  '/components/icons/ListBulletIcon.tsx',
  '/components/icons/ListNumberedIcon.tsx',
  '/components/icons/LockIcon.tsx',
  '/components/icons/LogoIcon.tsx',
  '/components/icons/MenuIcon.tsx',
  '/components/icons/MoonIcon.tsx',
  '/components/icons/OutdentIcon.tsx',
  '/components/icons/PdfIcon.tsx',
  '/components/icons/PinIcon.tsx',
  '/components/icons/PlusIcon.tsx',
  '/components/icons/RedoIcon.tsx',
  '/components/icons/ReminderIcon.tsx',
  '/components/icons/RenameIcon.tsx',
  '/components/icons/RestoreIcon.tsx',
  '/components/icons/SearchIcon.tsx',
  '/components/icons/SelectAllIcon.tsx',
  '/components/icons/SettingsIcon.tsx',
  '/components/icons/ShareIcon.tsx',
  '/components/icons/SortIcon.tsx',
  '/components/icons/StarIcon.tsx',
  '/components/icons/StrikethroughIcon.tsx',
  '/components/icons/SunIcon.tsx',
  '/components/icons/TodoIcon.tsx',
  '/components/icons/TrashIcon.tsx',
  '/components/icons/UnarchiveIcon.tsx',
  '/components/icons/UnderlineIcon.tsx',
  '/components/icons/UndoIcon.tsx',
  '/components/icons/XIcon.tsx',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
  'https://esm.sh/react@19.1.1',
  'https://esm.sh/react-dom@19.1.1/client',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Clone the request to use it both for cache and network
        const fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(
          response => {
            // Check if we received a valid response
            if (!response || response.status !== 200 && response.status !== 0) {
              return response;
            }

            // Clone the response to use it both for browser and cache
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                // We don't cache chrome-extension:// requests
                if(!event.request.url.startsWith('chrome-extension://')) {
                  cache.put(event.request, responseToCache);
                }
              });

            return response;
          }
        );
      })
  );
});
