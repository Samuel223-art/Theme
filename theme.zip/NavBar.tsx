
import React from 'react';
import LogoIcon from './icons/LogoIcon';
import PlusIcon from './icons/PlusIcon';
import MenuIcon from './icons/MenuIcon';
import SortIcon from './icons/SortIcon';

interface NavBarProps {
  onAddClick: () => void;
  onMenuClick: () => void;
  onSortClick: () => void;
  showAddButton?: boolean;
  showSortButton?: boolean;
  actionText?: string;
  onActionClick?: () => void;
}

const NavBar: React.FC<NavBarProps> = ({ onAddClick, onMenuClick, onSortClick, showAddButton = true, showSortButton = false, actionText, onActionClick }) => {
  return (
    <header className="bg-white/80 dark:bg-black/80 backdrop-blur-lg sticky top-0 z-50 border-b border-gray-200 dark:border-gray-900">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left side: Logo */}
          <div className="flex-shrink-0">
            <a href="#" className="flex items-center space-x-3" aria-label="Home">
              <LogoIcon className="h-7 w-auto" />
              <span className="font-bold text-xl text-gray-800 dark:text-gray-200">X Note</span>
            </a>
          </div>

          {/* Right side: Icons */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {actionText && onActionClick && (
              <button
                type="button"
                onClick={onActionClick}
                className="px-3 py-1.5 rounded-md text-sm font-semibold text-red-600 dark:text-red-500 hover:bg-red-500/10 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-red-500 transition-colors duration-200"
              >
                {actionText}
              </button>
            )}
             {showSortButton && (
                <button
                    type="button"
                    onClick={onSortClick}
                    className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-800 dark:hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
                    aria-label="Sort notes"
                >
                    <SortIcon className="h-6 w-6" />
                </button>
            )}
            {showAddButton && (
              <button
                type="button"
                onClick={onAddClick}
                className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-800 dark:hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
                aria-label="Add new note"
              >
                <PlusIcon className="h-6 w-6" />
              </button>
            )}
            <button
              type="button"
              onClick={onMenuClick}
              className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-800 dark:hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black focus:ring-gray-500 transition-colors duration-200"
              aria-label="Open menu"
            >
              <MenuIcon className="h-6 w-6" />
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default NavBar;
