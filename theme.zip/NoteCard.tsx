
import React, { useRef, useState } from 'react';
import { Note } from '../App';
import CheckCircleIcon from './icons/CheckCircleIcon';
import TrashTimer from './TrashTimer';
import PinIcon from './icons/PinIcon';

interface SwipeAction {
  action: (noteId: string) => void;
  icon: React.ReactNode;
  color: string;
}

interface NoteCardProps {
  note: Note;
  onClick: () => void;
  onLongPress: (noteId: string) => void;
  isSelected: boolean;
  layout: 'grid' | 'list';
  density: 'comfortable' | 'compact';
  swipeLeftAction?: SwipeAction;
  swipeRightAction?: SwipeAction;
}

const NoteCard: React.FC<NoteCardProps> = ({ 
  note, onClick, onLongPress, isSelected, layout, density, swipeLeftAction, swipeRightAction 
}) => {
  const [translateX, setTranslateX] = useState(0);
  const touchStartX = useRef(0);
  const cardRef = useRef<HTMLDivElement>(null);
  const longPressTimer = useRef<number>(0);
  const isLongPressed = useRef(false);
  const isSwiping = useRef(false);
  const SWIPE_THRESHOLD = 80;

  const createSnippet = (html: string, maxLength: number = 100): string => {
    if (!html) return 'No content';
    
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    const text = tempDiv.textContent || tempDiv.innerText || '';
    
    if (text.length <= maxLength) {
      return text;
    }
    
    return text.substring(0, maxLength).trim() + '...';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    isLongPressed.current = false;
    isSwiping.current = false;
    touchStartX.current = e.touches[0].clientX;
    cardRef.current?.style.setProperty('transition', 'transform 0s');

    longPressTimer.current = window.setTimeout(() => {
      if (!isSwiping.current) {
        isLongPressed.current = true;
        onLongPress(note.id);
      }
    }, 500);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const currentX = e.touches[0].clientX;
    const deltaX = currentX - touchStartX.current;
    
    if (Math.abs(deltaX) > 10 && !isSwiping.current) {
        isSwiping.current = true;
        clearTimeout(longPressTimer.current);
    }

    if (isSwiping.current) {
        // Prevent swiping right further than the threshold for the left action, and vice-versa
        const canSwipeRight = !!swipeRightAction;
        const canSwipeLeft = !!swipeLeftAction;
        
        if (!canSwipeRight && deltaX > 0) {
            setTranslateX(0);
        } else if (!canSwipeLeft && deltaX < 0) {
            setTranslateX(0);
        } else {
            setTranslateX(deltaX);
        }
    }
  };

  const handleTouchEnd = () => {
    clearTimeout(longPressTimer.current);
    cardRef.current?.style.setProperty('transition', 'transform 0.2s ease-out');
    
    if (Math.abs(translateX) > SWIPE_THRESHOLD) {
      if (translateX > 0 && swipeRightAction) {
        setTranslateX(window.innerWidth);
        setTimeout(() => swipeRightAction.action(note.id), 200);
      } else if (translateX < 0 && swipeLeftAction) {
        setTranslateX(-window.innerWidth);
        setTimeout(() => swipeLeftAction.action(note.id), 200);
      }
    } else {
      setTranslateX(0);
    }
    touchStartX.current = 0;
  };
  
  const handleClick = () => {
    if (!isLongPressed.current && !isSwiping.current) {
      onClick();
    }
  };

  const baseClasses = "relative bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg text-left hover:bg-gray-50 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-transparent focus:ring-gray-400 dark:focus:ring-gray-600 transition-all duration-200 transform hover:-translate-y-1 w-full overflow-hidden select-none z-10";
  const selectedClasses = "ring-2 ring-gray-500 border-gray-400 dark:border-gray-700 bg-gray-100 dark:bg-gray-800/50";
  const densityClasses = density === 'compact' ? 'p-3' : 'p-4';
  const layoutClasses = layout === 'grid' ? 'h-full flex flex-col' : 'flex items-center';

  const GridView = () => (
    <div className={`flex flex-col h-full ${densityClasses} ${note.isTrashed ? 'pb-6' : ''}`}>
      <h3 className="font-bold text-lg text-gray-800 dark:text-gray-200 mb-2 truncate">{note.title}</h3>
      <p className="text-gray-600 dark:text-gray-400 text-sm flex-grow mb-4">{createSnippet(note.content)}</p>
      {!note.isTrashed && <p className="text-xs text-gray-500 dark:text-gray-500 mt-auto">{formatDate(note.updatedAt)}</p>}
    </div>
  );

  const ListView = () => (
     <div className={`flex items-center w-full ${densityClasses}`}>
        {note.isPinned && (
           <div className="mr-3 flex-shrink-0 text-gray-500 dark:text-gray-400">
                <PinIcon className="h-4 w-4 -rotate-45" />
           </div>
        )}
        <div className="flex-grow overflow-hidden">
            <h3 className="font-bold text-gray-800 dark:text-gray-200 truncate">{note.title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 truncate">{createSnippet(note.content, 200)}</p>
        </div>
        {!note.isTrashed && (
            <p className="text-xs text-gray-500 dark:text-gray-500 ml-4 flex-shrink-0">{formatDate(note.updatedAt)}</p>
        )}
     </div>
  );
  
  const rightOpacity = Math.max(0, Math.min(1, translateX / SWIPE_THRESHOLD));
  const leftOpacity = Math.max(0, Math.min(1, -translateX / SWIPE_THRESHOLD));

  return (
    <div className="relative">
        <div className="absolute inset-0 flex justify-between items-center rounded-lg overflow-hidden">
            {swipeRightAction && (
                <div className={`h-full flex-1 flex items-center justify-start pl-6 ${swipeRightAction.color}`} style={{ opacity: rightOpacity }}>
                   {swipeRightAction.icon}
                </div>
            )}
            {swipeLeftAction && (
                <div className={`h-full flex-1 flex items-center justify-end pr-6 ${swipeLeftAction.color}`} style={{ opacity: leftOpacity }}>
                   {swipeLeftAction.icon}
                </div>
            )}
        </div>
        <div 
            ref={cardRef}
            style={{ transform: `translateX(${translateX}px)`, touchAction: 'pan-y' }}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
        >
          <button
            type="button"
            onClick={handleClick}
            className={`${baseClasses} ${layoutClasses} ${isSelected ? selectedClasses : ''}`}
            aria-pressed={isSelected}
            aria-label={`Note titled ${note.title}`}
          >
            {layout === 'grid' ? <GridView /> : <ListView />}

            {note.isTrashed && note.trashedAt && (
                <TrashTimer trashedAt={note.trashedAt} />
            )}
          </button>
        </div>
      {note.isPinned && layout === 'grid' && (
        <div className="absolute top-2 left-2 text-gray-500 dark:text-gray-400 pointer-events-none z-20">
            <PinIcon className="h-4 w-4 -rotate-45" />
        </div>
      )}

      {isSelected && (
        <div className="absolute top-3 right-3 text-white pointer-events-none bg-black/50 rounded-full z-20">
          <CheckCircleIcon className="h-6 w-6" />
        </div>
      )}
    </div>
  );
};

export default NoteCard;
